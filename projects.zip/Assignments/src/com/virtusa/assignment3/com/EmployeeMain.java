package com.virtusa.assignment3.com;

public class EmployeeMain {

	public static void main(String[] args) {
		String empDetails[] = {
				"1,John,25,250000,john@email.com,51 Ram Street,Venkat Nagar,Thoraipakkam,Chennai,600001",
				"2,Jon,26,500000,jon@email.com,51 famous Street,Venky Nagar,Thoraipakkam,Chennai,600001",
				"3,Johny,30,750000,johny@email.com,51 white Street,raju Nagar,Thoraipakkam,Chennai,600001",
				"4,Johnny,28,350000,johnny@email.com,51 black Street,Venk Nagar,Thoraipakkam,Chennai,600001",
				"5,Jonn,22,870000,jonn@email.com,51 eden Street,Venkat Nagar,Thoraipakkam,Chennai,600001",
				"6,Jonny,35,590000,jonny@email.com,51 Ram Street,Venkat Nagar,Thoraipakkam,Chennai,600001" };
		for (int i = 0; i < empDetails.length; i++) {
			String temp = empDetails[i];
			String arr[] = temp.split(",");
			int sno = Integer.parseInt(arr[0]);
			String ename = arr[1];
			int age = Integer.parseInt(arr[2]);
			Float salary = Float.parseFloat(arr[3]);
			String email = arr[4];
			String addresslane1 = arr[5];
			String addresslane2 = arr[6];
			String locality = arr[7];
			String city = arr[8];
			String pincode = arr[9];
			Address address = new Address(addresslane1, addresslane2, locality, city, pincode);
			Employee emp = new Employee(sno, ename, age, salary, pincode, address);
			float tax = TaxCalculation.calTax(salary);
			System.out.println(emp);
			System.out.println("employee:  " + (i+1) + " having tax: " + tax);

		}

	}
}
