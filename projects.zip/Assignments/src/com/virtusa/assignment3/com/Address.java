package com.virtusa.assignment3.com;

public class Address {
	private String addresslane1;
	private String addresslane2;
	private String locality;
	private String city;
	private String pincode;
	public String getAddresslane1() {
		return addresslane1;
	}
	public void setAddresslane1(String addresslane1) {
		this.addresslane1 = addresslane1;
	}
	public String getAddresslane2() {
		return addresslane2;
	}
	public void setAddresslane2(String addresslane2) {
		this.addresslane2 = addresslane2;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public Address(String addresslane1, String addresslane2, String locality, String city, String pincode) {
		super();
		this.addresslane1 = addresslane1;
		this.addresslane2 = addresslane2;
		this.locality = locality;
		this.city = city;
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [addresslane1=" + addresslane1 + ", addresslane2=" + addresslane2 + ", locality=" + locality
				+ ", city=" + city + ", pincode=" + pincode + "]";
	}

	

}
