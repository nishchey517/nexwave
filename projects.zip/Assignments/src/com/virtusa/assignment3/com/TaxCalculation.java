package com.virtusa.assignment3.com;

public class TaxCalculation {

	float tax;

	public static float calTax(float salary) {
		if (salary <= 250000) {
			return 0;
		} else if (salary > 250000 && salary <= 500000) {
			return ((salary - 250000) * 5) / 100;
		} else if (salary > 500000 && salary <= 1000000) {
			return (((salary - 500000) * 20) / 100) + 12500;
		} else
			return 0;
	}

}
