package com.virtusa.assignment3.com;

public class Employee {

	private int sno;
	private String ename;
	private int age;
	private float salary;
	private String email;
	Address address;

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Employee(int sno, String ename, int age, Float salary, String email, Address address) {
		super();
		this.sno = sno;
		this.ename = ename;
		this.age = age;
		this.salary = salary;
		this.email = email;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [sno=" + sno + ", ename=" + ename + ", age=" + age + ", salary=" + salary + ", email=" + email
				+ ", address=" + address + "]";
	}

}
