package com.virtusa.assignment2.com;

public class Account {
	private String accountNumber;
	private float mainBalance;

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", mainBalance=" + mainBalance + "]";
	}

	public Account(String accountNumber, float mainBalance) {
		super();
		this.accountNumber = accountNumber;
		this.mainBalance = mainBalance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public float getMainBalance() {
		return mainBalance;
	}

	public void setMainBalance(float mainBalance) {
		this.mainBalance = mainBalance;
	}
	public void transaction(char transactionType,float transactionAmount) {
		if(transactionType=='W'|| transactionType=='w') {
			withdraw(transactionAmount);
		}
		else if(transactionType=='D'|| transactionType=='d') {
			deposit(transactionAmount);
		}
	}

	public void withdraw(float transactionAmount) {
		System.out.println("Your Balance in your Account " + this.accountNumber + " is :" + this.mainBalance);
		if (this.mainBalance < transactionAmount) {
			System.out.println("Transaction failed due to insuffient balance in your account"
					+ " your account Number is:" + this.accountNumber);
		} else {
			this.mainBalance = this.mainBalance - transactionAmount;
			System.out.println("Your account balance after withdrawing amount "+transactionAmount+"is :" + this.mainBalance);
		}
	}

	public void deposit(float transactionAmount) {
		System.out.println("Your Balance in your Account " + this.accountNumber + " is :" + this.mainBalance);
		if (transactionAmount > 50000) {
			System.out.println("Transaction failed due to depositing amount exceeded the limit");
		} else {
			this.mainBalance = this.mainBalance + transactionAmount;
			System.out.println("Your account balance after depositing amount "+transactionAmount+"is :" + this.mainBalance);
		}
	}

}