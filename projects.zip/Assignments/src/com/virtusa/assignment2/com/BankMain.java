package com.virtusa.assignment2.com;

import com.virtusa.assignment2.com.Account;

public class BankMain {

	public static void main(String[] args) {
//		Account account=new Account("15R01A0571",500001);
//		Account account1=new Account("15R01A0572",5000);
//		account.transaction('w', 50000);
//		account.transaction('d', 5000000);
//		account1.transaction('w', 6000);
//		account1.transaction('d', 500);
		String[] data={"15R01A0571,50000,d,1000","15R01A0572,20000,d,2000","15R01A0573,30000,d,1000","15R01A0574,90000,d,1000"};
		for(int i=0;i<data.length;i++)
		{
			String temp=data[i];
			String arr[]=temp.split(",");
			String accountNumber = arr[0];
			float amount = Float.parseFloat(arr[1]);
			char transType=arr[2].charAt(0);
		    float transAmount = Float.parseFloat(arr[3]);	
		    Account account=new Account(accountNumber,amount);
		    account.transaction(transType,transAmount);
		}
	}

}
