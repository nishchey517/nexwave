package com.virtusa.assignment4.com;

public class CreditCardAccount extends BankAccount {
	private int rewardPoints;

	public CreditCardAccount(String accountNumber, float mainBalance,boolean isPriviledge) {
		super(accountNumber, mainBalance,isPriviledge);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void withdraw(float transactionAmount) {
		System.out.println("Your Balance in your Account " + this.accountNumber + " is :" + this.mainBalance);
		if ( transactionAmount>15000) {
			System.out.println("Transaction failed the limit of the credit card is only 15000"
					+ " your account Number is:" + this.accountNumber);
		} else {
			
			int rewards = (int) (transactionAmount / 100);
			rewardPoints = rewards * 10;
			this.mainBalance = this.mainBalance - transactionAmount;
			System.out.println("Your account balance after withdrawing amount " + transactionAmount
					+ " and you are been deducted with" + " and having balance :" + this.mainBalance);
			System.out.println("Reward Points you got are " + rewardPoints);
		}
		
		
	}

	@Override
	public String toString() {
		return "CreditCardAccount [rewardPoints=" + rewardPoints + ", accountNumber=" + accountNumber + ", mainBalance="
				+ mainBalance + "]";
	}

	@Override
	public void deposit(float transactionAmount) {
		System.out.println("Account  NUmber: "+this.accountNumber);
		System.out.println("Before Transaction "+this.mainBalance);
		if (transactionAmount > 100000) {
			System.out.println("Transaction failed due to depositing amount exceeded the limit 1000000 and your 2");
		} else  {
			this.mainBalance = this.mainBalance + transactionAmount;
			System.out.println("Transaction is sucessful that you account is credited with " + transactionAmount
					+ " and you haven't got any bonus due to creditcard account");
			System.out.println("Your balance after transaction is" + mainBalance);
		}
		
	}

}
