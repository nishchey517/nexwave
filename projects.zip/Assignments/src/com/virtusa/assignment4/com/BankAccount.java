package com.virtusa.assignment4.com;

public class BankAccount {
	protected String accountNumber;
	protected float mainBalance;
	private boolean isPriviledge;
	private float finalFine;

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", mainBalance=" + mainBalance + "]";
	}

	public BankAccount(String accountNumber, float mainBalance,boolean isPriviledge) {
		super();
		this.accountNumber = accountNumber;
		this.mainBalance = mainBalance;
		this.isPriviledge=isPriviledge;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public float getMainBalance() {
		return mainBalance;
	}

	public void setMainBalance(float mainBalance) {
		this.mainBalance = mainBalance;
	}

	public void transaction(char transactionType, float transactionAmount) {
		if (transactionType == 'W' || transactionType == 'w') {
			withdraw(transactionAmount);
		} else if (transactionType == 'D' || transactionType == 'd') {
			deposit(transactionAmount);
		}
	}

	public void withdraw(float transactionAmount) {
		System.out.println("Your Balance in your Account " + this.accountNumber + " is :" + this.mainBalance);
		if (this.mainBalance < transactionAmount) {
			System.out.println("Transaction failed due to insuffient balance in your account"
					+ " your account Number is:" + this.accountNumber);
			System.out.println("your trasactionAmount "+transactionAmount);
		} else {
			if(!isPriviledge) {
			float fine = transactionAmount / 10000;
			 finalFine = fine * 10;
			 System.out.println("Yours is not priviledged Account so fine is "+finalFine);
			}
			else {
				finalFine=0;
			}
			this.mainBalance = this.mainBalance - transactionAmount - finalFine;
			System.out.println("Your account "+this.accountNumber+" balance after withdrawing amount " + transactionAmount
					+ " and you are been deducted with" + finalFine + " and having balance :" + this.mainBalance);
		}
	}

	public void deposit(float transactionAmount) {
		System.out.println("Your Balance in your Account " + this.accountNumber + " is :" + this.mainBalance);
			if (transactionAmount > 100000) {
			float interestL = (100000 * 2) / 100;
			float interest=(transactionAmount/10000)*interestL;
			this.mainBalance = this.mainBalance + transactionAmount + interest;
			System.out.println("Transaction is sucessful that you account is credited with " + transactionAmount
					+ " and you have got " + interest + " bonus");
			System.out.println("Your account "+this.accountNumber+" main balance is " + mainBalance);
		} else {
			this.mainBalance = this.mainBalance + transactionAmount;
			System.out.println(
					"Your account "+this.accountNumber+" balance after depositing amount " + transactionAmount + "is :" + this.mainBalance);
		}
	}

}