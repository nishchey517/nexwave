package com.virtusa.assignment4.com;

public class MainAccount {
	public static void main(String[] args) {
		String[] data={
				"15R01A0561,10000,w,15000,true,n",
				"15R01A0562,25000,w,20000,true,n",
				"15R01A0563,25000,w,20000,false,n",
				"15R01A0564,10000,d,200000,false,n",
				"15R01A0565,10000,d,200,true,n",
				"15R01A0566,10000,w,16000,true,c",
				"15R01A0567,10000,w,300,true,c",
				"15R01A0568,10000,d,10000,true,c"
		};
		for(int i=0;i<data.length;i++) {
			String temp=data[i];
			String[] lineData=temp.split(",");
			String accountNumber=lineData[0];
			float mainBalance=Float.parseFloat(lineData[1]);
			char transactionType=lineData[2].charAt(0);
			float transactionAmount=Float.parseFloat(lineData[3]);
			boolean isPriviledge=Boolean.parseBoolean(lineData[4]);
			char accountType=lineData[5].charAt(0);
			if(accountType=='n'||accountType=='N') {
			BankAccount bankAccount=new BankAccount(accountNumber, mainBalance, isPriviledge);
			bankAccount.transaction(transactionType, transactionAmount);
			}
			else if(accountType=='c'||accountType=='C') {
				CreditCardAccount creditCard=new CreditCardAccount(accountNumber, mainBalance, isPriviledge);
				creditCard.transaction(transactionType, transactionAmount);
			}
			System.out.println("==============================================================================");
		}
		
	}
}
