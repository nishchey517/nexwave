package com.virtusa.assignment1.com;

public class BankMain {
	public static void main(String[] args) {
		Account account=new Account("15R01A0571",500001);
		Account account1=new Account("15R01A0572",5000);
		account.withdraw(500);
		account.deposit(500000);
		account1.deposit(5000);
		account1.withdraw(100000);
		
	}
}
