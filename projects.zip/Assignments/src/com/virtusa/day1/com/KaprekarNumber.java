package com.virtusa.day1.com;

public class KaprekarNumber {

	public static void main(String[] args) {
		int square = 0;
		int count = 0;
		int secondHalf = 0, firstHalf = 0, k = 1;
		for (int i = 1; i < 100; i++) {
			square = i * i;
			int l = i;
			if (i == 1) {
				System.out.println("1 is a kaprakan");
			} else {
				while (l > 0) {
					count++;
					l = l / 10;
				}
				for (int j = 0; j < count; j++) {
					secondHalf = secondHalf + square % 10 * (k);
					square = square / 10;
					k = k * 10;

				}
				firstHalf = square;
				//System.out.println(secondHalf + "  " + firstHalf);
				if (secondHalf > 0 && firstHalf > 0) {
					if (firstHalf + secondHalf == i) {
						System.out.println(i + " is a kaprakan");
					}
					// else {
//						System.out.println(i + " Is not a kaprakan");
//					}
//
//				} else {
//					System.out.println(i + " Is not a kaprakan");
//				}
				}
				count = 0;
				k = 1;
				firstHalf = 0;
				secondHalf = 0;
			}
		}

	}
}
