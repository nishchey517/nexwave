package com.virtusa.day1.com;

public class PrimeNumbers {

}
