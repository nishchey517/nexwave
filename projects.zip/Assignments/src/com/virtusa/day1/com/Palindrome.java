package com.virtusa.day1.com;

public class Palindrome {
	public static void main(String[] args) {
		for (int i = 1; i <= 99; i++) {
			int l = i, sum = 0, m = 1;
			while (l > 0) {
				int r = l % 10;
				l = l / 10;
				sum = sum * m + r;
				m = m * 10;
			}
			if (sum == i) {
				System.out.println(i + " is a plaindrome");
			}
		}
	}
}
