package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;

@Entity
@Table(name="Account")
public class Account 
{
	@Id
	@Column(length=16)
	private long accountNumber;
	@Column(nullable=false)
	private String bankName;
	@Column(nullable=false)
	private String bankIfsc;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNumber, String bankName, String bankIfsc) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.bankIfsc = bankIfsc;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankIfsc() {
		return bankIfsc;
	}
	public void setBankIfsc(String bankIfsc) {
		this.bankIfsc = bankIfsc;
	}
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", bankName=" + bankName + ", bankIfsc=" + bankIfsc + "]";
	}
	
}
