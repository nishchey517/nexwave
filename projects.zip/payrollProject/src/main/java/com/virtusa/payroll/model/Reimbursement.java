package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="reimbursement")
public class Reimbursement 
{
	@Id
	private int reId;
	@Column(nullable=false)
	private String reType;
	@Column(nullable=false)
	private float reAmount;
	@Column(nullable=false)
	private String rePath;
	
	@ManyToOne(optional = false)
    @JoinColumn(name = "empId")
	private Employee employee;
	
	public Reimbursement() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getReId() {
		return reId;
	}
	public void setReId(int reId) {
		this.reId = reId;
	}
	public String getReType() {
		return reType;
	}
	public void setReType(String reType) {
		this.reType = reType;
	}
	public float getReAmount() {
		return reAmount;
	}
	public void setReAmount(float reAmount) {
		this.reAmount = reAmount;
	}
	public String getRePath() {
		return rePath;
	}
	public void setRePath(String rePath) {
		this.rePath = rePath;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Reimbursement [reId=" + reId + ", reType=" + reType + ", reAmount=" + reAmount + ", rePath=" + rePath
				+ ", employee=" + employee + "]";
	}
	public Reimbursement(int reId, String reType, float reAmount, String rePath) {
		super();
		this.reId = reId;
		this.reType = reType;
		this.reAmount = reAmount;
		this.rePath = rePath;
	}
	
	
	
	
}
