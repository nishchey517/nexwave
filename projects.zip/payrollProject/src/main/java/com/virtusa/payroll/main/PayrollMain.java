package com.virtusa.payroll.main;

import com.virtusa.payroll.model.Account;


public class PayrollMain 
{
	public static void main(String[] args)
	{
		Account account=new Account();
		account.setAccountNumber(1279000160621070l);
		account.setBankName("HDFC");
		account.setBankIfsc("HDFC000036");
		
		
		
	}
}
