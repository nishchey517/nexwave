package com.virtusa.payroll.main;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Reimbursement;

public class Main 
{
	public static void main(String[] args)
	{
		Reimbursement reimbursement=new Reimbursement(4, "LTA", 1200, "vxd");
		Reimbursement reimbursement2=new Reimbursement(5, "Food", 2200, "vvx");
		Reimbursement reimbursement3=new Reimbursement(6, "Child", 200, "vdvx");
		//Reimbursement reimbursement4=new Reimbursement(4, "LTA", 1245, "vxdzvx");
		
		Employee employee=new Employee(2, "Shubham Bansal", "Other");
		
        List<Reimbursement> allReimbursements = new ArrayList<Reimbursement>();
 
        reimbursement.setEmployee(employee);
        reimbursement2.setEmployee(employee);
        reimbursement3.setEmployee(employee);
 
        allReimbursements.add(reimbursement);
        allReimbursements.add(reimbursement2);
        allReimbursements.add(reimbursement3);
 
        employee.setReimbursement(allReimbursements);
		
		
		
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.save(employee);
		//session.saveOrUpdate(employee2);
		
		transaction.commit();
		session.close();
		
		
	}	
}
