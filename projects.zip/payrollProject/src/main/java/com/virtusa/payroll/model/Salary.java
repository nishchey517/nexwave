package com.virtusa.payroll.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Salary")
public class Salary 
{
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int salaryId;
	@Column(nullable=false)
	private int salaryPackage;
	@Column(nullable=false)
	private float salaryBasic;
	@Column(nullable=false)
	private float salaryHra;
	private float salaryBonus;
	@Column(nullable=false)
	private float salaryAllowance;
	public Salary() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
