package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class statementDemo 
{
	public static void main(String[] args) throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch (ClassNotFoundException e1) 
		{
			e1.printStackTrace();
		}
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbcdemo","root","root");
		Statement stmt = con.createStatement( );
		ResultSet rs = stmt.executeQuery("select name from student where name like 'N%' or name like 'n%' ;");
		while(rs.next())
		{
			System.out.println(rs.getString(1));
		}
		
		
		
	}
}
