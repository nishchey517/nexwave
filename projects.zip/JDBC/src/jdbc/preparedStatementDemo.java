package jdbc;

import java.io.*;
import java.math.BigInteger;
import java.sql.*;
import java.util.Scanner;

public class preparedStatementDemo {
	public static void main(String[] args) throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbcdemo", "root", "root");
		//BufferedReader d = new BufferedReader(new InputStreamReader(System.in));
		Scanner s=new Scanner(System.in);
		while (true) {
			System.out.println("Enter student roll number");
			int roll_number = s.nextInt();//Integer.parseInt(d.readLine());
			PreparedStatement pstmt = con.prepareStatement("select name,mobile from student where rollnumber="+roll_number);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1)+" "+rs.getLong(2));
			}
			
		}

	}

}
