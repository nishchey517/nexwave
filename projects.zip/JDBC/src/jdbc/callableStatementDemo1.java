package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Calendar;

public class callableStatementDemo1 {
	public static void main(String[] args) throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbcdemo", "root", "root");
		CallableStatement cstmt = con.prepareCall("call age(?,?,?,?,?)");

		Calendar cal = Calendar.getInstance();
		cal.set(2000,0,1);

		java.sql.Date dob = new java.sql.Date(cal.getTimeInMillis());
		java.sql.Date now = new java.sql.Date(System.currentTimeMillis());
		//java.sql.Date now = new java.sql.Date(new java.util.Date( ).getTime());

		cstmt.setDate(1,dob);
		cstmt.setDate(2, now);
							
		cstmt.registerOutParameter(3,Types.INTEGER);
		cstmt.registerOutParameter(4,Types.INTEGER);  
		cstmt.registerOutParameter(5,Types.INTEGER);
								
		cstmt.execute( );			

		System.out.println("Years: "+ cstmt.getInt(3));    
		System.out.println("Months:" + cstmt.getInt(4));
		System.out.println("Days: "+cstmt.getInt(5));				
		
	}
}
