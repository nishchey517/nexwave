package com.virtusa.payroll.service;

public interface IMessages  {
	public String contactAdmin="Internal Error please contact admin";
}
