package com.virtusa.payroll.service;

public class PayrollService {

	public PayrollService() {
		// TODO Auto-generated constructor stub
	}

}
