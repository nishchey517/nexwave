package com.virtusa.payroll.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class PayrollDaoTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void testPayrollDao() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoLoginCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoFirstUserCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateSecurityCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoSecurityCheck() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdatePassword() {
		fail("Not yet implemented");
	}

	@Test
	public void testRetrieveResult() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckEmployeeId() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewPayslip() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewCtc() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoInvestmentDeclaration() {
		fail("Not yet implemented");
	}

	@Test
	public void testClaimReimbursement() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetBenefitDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testChangeBenefitDetail() {
		fail("Not yet implemented");
	}

}
