package com.virtusa.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.BenefitDetail;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Investment;
import com.virtusa.payroll.model.LoginDetail;
import com.virtusa.payroll.model.PayrollData;
import com.virtusa.payroll.model.Reimbursement;
import com.virtusa.payroll.model.Salary;
import com.virtusa.payroll.model.Security;

import com.virtusa.payroll.service.IPayroll;
import com.virtusa.payroll.util.ConnectionUtil;

public class PayrollDao implements IPayroll {

	public PayrollDao() {
		
	}

	@Override
	public int doLoginCheck(LoginDetail loginDetail) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		try {
			
			preparedStatement = connection.prepareStatement("select emp_id,emp_password from employee where emp_id=? and emp_password=?");
			preparedStatement.setString(1, loginDetail.getUsername());
			preparedStatement.setString(2, loginDetail.getPassword());
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;
			}
		} catch (SQLException e) {
			throw new PayrollException("Some internal error contact to admin");
		}
		finally{
			System.out.println("closed");
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		return flag;
	}

	@Override
	public int doFirstUserCheck(int employeeId) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		try {
			preparedStatement = connection.prepareStatement("select sec_id from security where sec_id=" + employeeId);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;
			}
		} catch (SQLException e) {
			throw new PayrollException("Some internal error contact to admin");
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		return flag;
	}

	@Override
	public int createSecurityCheck(Security securityDetail) throws PayrollException {

		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement("insert into security values(?,?,?)");

			preparedStatement.setInt(1, securityDetail.getSec_id());
			preparedStatement.setString(2, securityDetail.getSec_question());
			preparedStatement.setString(3, securityDetail.getSec_ans());
			flag=preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}

		return flag;
	}

	@Override
	public int doSecurityCheck(Security securityDetail) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		try {
			preparedStatement = connection.prepareStatement("select sec_ans from security where sec_id=? and sec_ans=?");
			preparedStatement.setInt(1, securityDetail.getSec_id());
			preparedStatement.setString(2, securityDetail.getSec_ans());
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;
			}
		} catch (SQLException e) {
			throw new PayrollException("Some internal error contact to admin");
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		
		return flag;
	}

	@Override
	public int updatePassword(LoginDetail loginDetail) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement("update employee set emp_password=? where emp_id=?");

			preparedStatement.setString(1, loginDetail.getPassword());
			preparedStatement.setString(2, loginDetail.getUsername());

			flag=preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}
		return flag;

	}

	@Override
	public String retrieveResult(int emp_id) throws PayrollException {
		String question = "";
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
	
		try {
			preparedStatement = connection.prepareStatement("select sec_question from security where sec_id=?");
			preparedStatement.setInt(1, emp_id);

			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				question = resultSet.getString("sec_question");
			}
		} catch (SQLException e) {
			throw new PayrollException("Some internal error contact to admin");
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}
		return question;

	}

	@Override
	public int checkEmployeeId(int emp_id) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet=null;
		try {
			preparedStatement = connection.prepareStatement("select sec_id from security where sec_id=?");
			preparedStatement.setInt(1, emp_id);

			 resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;
			}
		} catch (SQLException e) {
			throw new PayrollException("Some internal error contact to admin");
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		
		return flag;
	}

	@Override
	public Employee viewDetails(int empid) throws PayrollException 
	{
		ResultSet resultSet=null;

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		Employee employeeDetails=new Employee();
		System.out.println("gai");
			
			try {
				System.out.println(connection);
				preparedStatement = connection.prepareStatement("select * from employee where emp_id="+empid);
				resultSet= preparedStatement.executeQuery();
				if (resultSet.next()) 
				{		
					System.out.println("found");
					employeeDetails.setEmp_name(resultSet.getString("emp_name"));
					employeeDetails.setEmp_gender(resultSet.getString("emp_gender"));
					System.out.println("yes foun");
					employeeDetails.setEmp_address(resultSet.getString("emp_address"));
					System.out.println("yes foun");
					employeeDetails.setEmp_contact(resultSet.getInt("emp_contact"));
					employeeDetails.setEmp_pan(resultSet.getString("emp_pan"));
					employeeDetails.setEmp_email(resultSet.getString("emp_mail"));
					System.out.println("yes found");
				}



			} 
			catch (SQLException e)
			{
				
				//logger.error("sql error", e);
				throw new PayrollException(e.getMessage());
			}
			finally{
				ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
			}
			
			return employeeDetails;
		}

	@Override
	public int updateDetails(Employee employeeDetails1) throws PayrollException {
		int flag=0;
		
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		System.out.println(employeeDetails1);
		try{
			System.out.println(connection);
			preparedStatement = connection.prepareStatement(
					"update employee set emp_name=?,emp_gender=?,emp_address=?,emp_contact=?,emp_pan=?,emp_mail=? where emp_id=?"	);
			preparedStatement.setInt(7, employeeDetails1.getEmp_id());

			preparedStatement.setString(1, employeeDetails1.getEmp_name());
			preparedStatement.setString(2, employeeDetails1.getEmp_gender());
			
			preparedStatement.setString(3, employeeDetails1.getEmp_address());
			preparedStatement.setInt(4, employeeDetails1.getEmp_contact());
			preparedStatement.setString(5, employeeDetails1.getEmp_pan());
			preparedStatement.setString(6, employeeDetails1.getEmp_email());
			flag=preparedStatement.executeUpdate();
			System.out.println(flag);

		}catch (SQLException e) {
			
		//	logger.error("sql error", e);
			throw new PayrollException(e.getMessage());
		} 
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}
		return flag;

	}

	@Override
	public String viewPayslip(PayrollData payrollData) throws PayrollException {
		String path = "";
		ResultSet resultSet = null;

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement(
					"select pay_details from payroll_data where pay_emp_fk=? and pay_month=? and pay_year=?");
			System.out.println(payrollData.getEmployee().getEmp_id());
			System.out.println(payrollData.getPay_month());
			System.out.println(payrollData.getPay_year());
			preparedStatement.setInt(1, payrollData.getEmployee().getEmp_id());
			preparedStatement.setString(2, payrollData.getPay_month());
			preparedStatement.setInt(3, payrollData.getPay_year());
			resultSet = preparedStatement.executeQuery();
			System.out.println("hai");
			if (resultSet.next()) {
				System.out.println("hai");
				path = resultSet.getString("pay_details");
				System.out.println("path is " + path);
			}

		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}

		return path;
	}

	@Override
	public Salary viewCtc(int employeeId) throws PayrollException {
		

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Salary salaryDetail = new Salary();
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement(
					"select s.* from Salary s join Employee e on  s.sal_id=e.emp_sal_fk where e.emp_id=" + employeeId);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				salaryDetail.setSal_package(resultSet.getInt(2));
				salaryDetail.setSal_basic(resultSet.getFloat(3));
				salaryDetail.setSal_hra(resultSet.getFloat(4));
				salaryDetail.setSal_bonus(resultSet.getFloat(5));
				salaryDetail.setSal_allowance(resultSet.getFloat(6));
			
			}

		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		return salaryDetail;

		// return 0;
	}

	@Override
	public int doInvestmentDeclaration(int emp_id, Investment investment) throws PayrollException {
		int flag = 0;
		ResultSet resultSet=null;
		Connection connection = ConnectionUtil.getConnection();
		Connection connection2= ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement retrieveStatement = null;
		try {
			System.out.println(connection);
			System.out.println(connection2);
				retrieveStatement=connection2.prepareStatement("select * from investment where inv_emp_fk="+emp_id);
				resultSet=retrieveStatement.executeQuery();
				
			
			
			
			
			preparedStatement = connection.prepareStatement(
					"update investment set inv_insurance=?,inv_eduloan=?,inv_ppf=?,inv_loan=? where inv_emp_fk=?");
			if(resultSet.next()){
				if(investment.getInv_insurance()!=""){
					preparedStatement.setString(1, investment.getInv_insurance());
				}
				else{
					preparedStatement.setString(1, resultSet.getString(3));
				}
				if(investment.getInv_eduloan()!=""){
					preparedStatement.setString(2, investment.getInv_eduloan());
				}
				else{
					preparedStatement.setString(2, resultSet.getString(4));
				}
				if(investment.getInv_ppf()!=""){
					preparedStatement.setString(3, investment.getInv_ppf());
				}
				else{
					preparedStatement.setString(3, resultSet.getString(5));
				}
				if(investment.getInv_loan()!=""){
					preparedStatement.setString(4, investment.getInv_loan());
				}
				else{
					preparedStatement.setString(4,resultSet.getString(6));
				}
				preparedStatement.setInt(5, emp_id);
			}
			flag = preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
			ConnectionUtil.closeConnection(retrieveStatement,resultSet, connection2);
		}
		return flag;

	}

	@Override
	public int claimReimbursement(int emp_id,Reimbursement reimbursement) throws PayrollException {
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			System.out.println(connection);
			preparedStatement = connection
					.prepareStatement("insert into reimbursement(re_emp_fk,re_type,re_amount,re_path) values(?,?,?,?)");

			
			preparedStatement.setString(2, reimbursement.getRe_type());
			preparedStatement.setFloat(3, reimbursement.getRe_amount());
			preparedStatement.setString(4, reimbursement.getRe_path());
			preparedStatement.setInt(1, emp_id);
		
			flag=preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}

		return flag;

	}
	@Override
	public BenefitDetail getBenefitDetails(int employeeId) throws PayrollException {
		ResultSet resultSet = null;

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		BenefitDetail employeeBenefitDetails = new BenefitDetail();
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement("select * from benefits where ben_emp_fk=" + employeeId);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				employeeBenefitDetails.setBen_lta(resultSet.getFloat(3));
				employeeBenefitDetails.setBen_phone(resultSet.getFloat(4));
				employeeBenefitDetails.setBen_childfee(resultSet.getFloat(5));
				employeeBenefitDetails.setBen_food(resultSet.getFloat(6));
			}

		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement,resultSet, connection);
		}
		return employeeBenefitDetails;
	}

	@Override
	public int changeBenefitDetail(BenefitDetail benefits) throws PayrollException {
		// TODO Auto-generated method stub
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement(
					"update Benefits set ben_lta=?,ben_phone=?,ben_childfee=?,ben_food=? where ben_emp_fk="
							+ benefits.getEmployee().getEmp_id());

			System.out.println("Statement");
			preparedStatement.setFloat(1, benefits.getBen_lta());
			preparedStatement.setFloat(2, benefits.getBen_phone());
			preparedStatement.setFloat(3, benefits.getBen_childfee());
			preparedStatement.setFloat(4, benefits.getBen_food());
			flag=preparedStatement.executeUpdate();
		
		} catch (SQLException e) {
			throw new PayrollException();
		}
		finally{
			ConnectionUtil.closeConnection(preparedStatement, connection);
		}
		return flag;

	}

}
