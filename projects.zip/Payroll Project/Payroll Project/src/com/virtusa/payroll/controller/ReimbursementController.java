package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Reimbursement;
import com.virtusa.payroll.service.IMessages;

@WebServlet("/ReimbursementController")
public class ReimbursementController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ReimbursementController() {
		super();

	}
@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	Logger logger=Logger.getLogger("doPost");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		PayrollDao service = new PayrollDao();
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher = null;
		if (session.getAttribute("user") != null) {
			int emp_id = Integer.parseInt(session.getAttribute("user").toString());
			Employee employee = new Employee();
			employee.setEmp_id(emp_id);
			String Re_type = request.getParameter("type");
			String amount = request.getParameter("Amount");
			float Re_amount = Float.parseFloat(amount);
			String Re_path = request.getParameter("proof");

			logger.info(Re_amount + "  " + Re_type + " " + Re_path);
			Reimbursement reimbursement = new Reimbursement();
			reimbursement.setEmployee(employee);
			reimbursement.setRe_type(Re_type);
			reimbursement.setRe_amount(Re_amount);
			reimbursement.setRe_path(Re_path);
			int flag = 0;

			try {
				flag = service.claimReimbursement(emp_id, reimbursement);
				if (flag == 1) {
					dispatcher = request.getRequestDispatcher("/jsp/success.jsp");
					dispatcher.forward(request, response);
				}
			} catch (PayrollException e) {
				out.println(IMessages.contactAdmin);
			}
		} else {
			dispatcher = request.getRequestDispatcher("/jsp/error.jsp");
			dispatcher.forward(request, response);
		}

	}

}
