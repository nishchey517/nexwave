package com.virtusa.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.payroll.service.IMessages;

@WebServlet("/LogOutController")
public class LogOutController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LogOutController() {
		super();
		
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger=Logger.getLogger("doGet");
		logger.info("Entered LogoutController");
		
		HttpSession session = request.getSession();
		RequestDispatcher rd = null;
		if (session.getAttribute("user") != null) {
			session.removeAttribute("userid");

			session.invalidate();
			rd = request.getRequestDispatcher("/jsp/Thankyou.jsp");
			rd.forward(request, response);

		} else {
			logger.error(IMessages.contactAdmin);
			rd = request.getRequestDispatcher("/jsp/error.jsp");
			rd.forward(request, response);
		}
	}

}
