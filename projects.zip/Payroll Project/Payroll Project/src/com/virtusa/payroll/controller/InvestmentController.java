package com.virtusa.payroll.controller;


import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.Investment;
import com.virtusa.payroll.service.IMessages;


@WebServlet("/InvestmentController")
public class InvestmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InvestmentController() {
		super();

	}
	
	private static final String UPLOADDIRECTORY ="D:/yesh/Payroll Web 1/payroll/investmentfiles/";
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger=Logger.getLogger("doPost");
		response.setContentType("text/html");
		RequestDispatcher dispatcher=null;
		HttpSession session = request.getSession();
		PayrollDao dao = new PayrollDao();
		logger.info("Entered InvestmentController");
		int employeeId = Integer.parseInt(session.getAttribute("user").toString());
		if (session.getAttribute("user") != null) {
			Investment investment = new Investment();
				logger.info("check");
				if(ServletFileUpload.isMultipartContent(request)){
					logger.info("check");
	                try {
	                    List<FileItem> multiparts = new ServletFileUpload(
	                                             new DiskFileItemFactory()).parseRequest(request);
	                    logger.info("check1");
	                    for(FileItem item : multiparts){
	                        if(!item.isFormField()){
	                            String name = new File(item.getName()).getName();
	                            logger.info("check"+name);
	                            item.write( new File(UPLOADDIRECTORY + File.separator + employeeId+session.getAttribute("type")+name.substring(name.indexOf('.'))));
	                        }
	                        logger.info("check");
	                    }
	                

	                } catch (Exception ex) {
	                   response.getWriter().print("File Upload Failed due to " + ex);
	                }   
	        	}
	        

			investment.setInv_insurance(employeeId+"insurance.pdf");
			investment.setInv_eduloan(employeeId+"eduloan.pdf");
			investment.setInv_ppf(employeeId+"ppf.pdf");
			investment.setInv_loan(employeeId+"loan.pdf");
			int flag = 0;

			try {
				flag = dao.doInvestmentDeclaration(employeeId, investment);
				if (flag == 1) {
					dispatcher = request.getRequestDispatcher("/jsp/success.jsp");
					dispatcher.forward(request, response);
				} else {
					dispatcher = request.getRequestDispatcher("/jsp/security.jsp");
					dispatcher.forward(request, response);
				}

			} catch (PayrollException e) {
				logger.error(IMessages.contactAdmin+e);
				dispatcher = request.getRequestDispatcher("/jsp/error.jsp");
				dispatcher.forward(request, response);
			}
		} else {
			logger.error(IMessages.contactAdmin);
			dispatcher = request.getRequestDispatcher("/jsp/error.jsp");
			dispatcher.forward(request, response);
		}

	}

}
