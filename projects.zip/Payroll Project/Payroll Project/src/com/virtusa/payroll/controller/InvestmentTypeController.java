package com.virtusa.payroll.controller;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.payroll.service.IMessages;

/**
 * Servlet implementation class InvestmentTypeController
 */
@WebServlet("/InvestmentTypeController")
public class InvestmentTypeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InvestmentTypeController() {
        super();

    }

	
   
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger logger=Logger.getLogger("doPost");
    	String type=request.getParameter("type");
		logger.info("Entered InvestmentTypeController");
		HttpSession session = request.getSession();
		RequestDispatcher dispatcher=null;
		if (session.getAttribute("user") != null) {
			if(type!=null){
				session.setAttribute("type",type);
				dispatcher=request.getRequestDispatcher("/jsp/uploadinvest.jsp");
				dispatcher.forward(request, response);
			}
			else{
				logger.error(IMessages.contactAdmin);
				dispatcher = request.getRequestDispatcher("/jsp/error.jsp");
				dispatcher.forward(request, response);
			}
		} else {
			logger.error(IMessages.contactAdmin);
			dispatcher = request.getRequestDispatcher("/jsp/error.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
