package com.virtusa.zomato.service;

import java.util.List;

import com.virtusa.zomato.exception.ZomatoException;
import com.virtusa.zomato.model.Customer;
import com.virtusa.zomato.model.LoginDetail;
import com.virtusa.zomato.model.OrderDetails;
import com.virtusa.zomato.model.Payment;
import com.virtusa.zomato.model.RestaurantMenuDetails;

public interface IZomato 
{
	public int doLoginCheck(LoginDetail loginDetail) throws ZomatoException;
	public int registerCustomer(Customer customerDetails) throws ZomatoException;
	public List<RestaurantMenuDetails> searchRestaurants(String text) throws ZomatoException;
	public int placeOrder(OrderDetails orderDetails) throws ZomatoException;
	public int doPayment(Payment paymentDetails) throws ZomatoException;

}


