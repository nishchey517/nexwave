package com.virtusa.zomato.service;

import java.util.List;

import com.virtusa.zomato.dao.ZomatoDao;
import com.virtusa.zomato.exception.ZomatoException;
import com.virtusa.zomato.model.Customer;
import com.virtusa.zomato.model.LoginDetail;
import com.virtusa.zomato.model.OrderDetails;
import com.virtusa.zomato.model.Payment;
import com.virtusa.zomato.model.RestaurantMenuDetails;

public class ZomatoService {
	public ZomatoService()
	{
		
	}
	private ZomatoDao zomatoDao=new ZomatoDao();
	public int doLoginCheck(LoginDetail loginDetail) throws ZomatoException {
		// TODO Auto-generated method stub
		return zomatoDao.doLoginCheck(loginDetail);
	}

	public int registerCustomer(Customer customerDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return zomatoDao.registerCustomer(customerDetails);
	}

	public List<RestaurantMenuDetails> searchRestaurants(String text) throws ZomatoException {
		// TODO Auto-generated method stub
		return zomatoDao.searchRestaurants(text);
	}

	public int placeOrder(OrderDetails orderDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return zomatoDao.placeOrder(orderDetails);
	}

	public int doPayment(Payment paymentDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return zomatoDao.doPayment(paymentDetails);
	}

}
