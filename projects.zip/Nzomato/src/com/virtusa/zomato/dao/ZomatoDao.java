package com.virtusa.zomato.dao;

import java.sql.Connection;
import java.util.List;

import com.virtusa.zomato.exception.ZomatoException;
import com.virtusa.zomato.model.Customer;
import com.virtusa.zomato.model.LoginDetail;
import com.virtusa.zomato.model.OrderDetails;
import com.virtusa.zomato.model.Payment;
import com.virtusa.zomato.model.RestaurantMenuDetails;
import com.virtusa.zomato.service.IZomato;
import com.virtusa.zomato.util.ConnectionUtil;

public class ZomatoDao implements IZomato {

	@Override
	public int doLoginCheck(LoginDetail loginDetail) throws ZomatoException {
		Connection connection=ConnectionUtil.getConnection();
		return 0;
	}

	@Override
	public int registerCustomer(Customer customerDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<RestaurantMenuDetails> searchRestaurants(String text) throws ZomatoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int placeOrder(OrderDetails orderDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doPayment(Payment paymentDetails) throws ZomatoException {
		// TODO Auto-generated method stub
		return 0;
	}

}
