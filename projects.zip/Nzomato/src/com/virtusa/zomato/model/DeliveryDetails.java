package com.virtusa.zomato.model;

public class DeliveryDetails 
{
	private int deliveryDetail_Id;
	private float rating;
	private Delivery delivery;
	private OrderDetails order_Details;
	@Override
	public String toString() {
		return "DeliveryDetails [deliveryDetail_Id=" + deliveryDetail_Id + ", rating=" + rating + ", delivery="
				+ delivery + ", order_Details=" + order_Details + "]";
	}
	public DeliveryDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DeliveryDetails(int deliveryDetail_Id, float rating, Delivery delivery, OrderDetails order_Details) {
		super();
		this.deliveryDetail_Id = deliveryDetail_Id;
		this.rating = rating;
		this.delivery = delivery;
		this.order_Details = order_Details;
	}
	public int getDeliveryDetail_Id() {
		return deliveryDetail_Id;
	}
	public void setDeliveryDetail_Id(int deliveryDetail_Id) {
		this.deliveryDetail_Id = deliveryDetail_Id;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public Delivery getDelivery() {
		return delivery;
	}
	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}
	public OrderDetails getOrder_Details() {
		return order_Details;
	}
	public void setOrder_Details(OrderDetails order_Details) {
		this.order_Details = order_Details;
	}
	
	
	
	
	
}
