package com.virtusa.zomato.model;

public class Admin
{
	private int admin_Id;
	private String admin_Name;
	private String admin_Email;
	private String admin_Phone;
	public int getAdmin_Id() {
		return admin_Id;
	}
	public void setAdmin_Id(int admin_Id) {
		this.admin_Id = admin_Id;
	}
	public String getAdmin_Name() {
		return admin_Name;
	}
	public void setAdmin_Name(String admin_Name) {
		this.admin_Name = admin_Name;
	}
	public String getAdmin_Email() {
		return admin_Email;
	}
	public void setAdmin_Email(String admin_Email) {
		this.admin_Email = admin_Email;
	}
	public String getAdmin_Phone() {
		return admin_Phone;
	}
	public void setAdmin_Phone(String admin_Phone) {
		this.admin_Phone = admin_Phone;
	}
	@Override
	public String toString() {
		return "admin [admin_Id=" + admin_Id + ", admin_Name=" + admin_Name + ", admin_Email=" + admin_Email
				+ ", admin_Phone=" + admin_Phone + "]";
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int admin_Id, String admin_Name, String admin_Email, String admin_Phone) {
		super();
		this.admin_Id = admin_Id;
		this.admin_Name = admin_Name;
		this.admin_Email = admin_Email;
		this.admin_Phone = admin_Phone;
	}
	
	
	
}
