package com.virtusa.zomato.model;

import java.time.LocalDate;

public class Offer 
{
	private int offer_Id;
	private String offer_Name;
	private int offer_Discount;
	private LocalDate start_Date;
	private LocalDate end_Date;
	@Override
	public String toString() {
		return "Offer [offer_Id=" + offer_Id + ", offer_Name=" + offer_Name + ", offer_Discount=" + offer_Discount
				+ ", start_Date=" + start_Date + ", end_Date=" + end_Date + "]";
	}
	public int getOffer_Id() {
		return offer_Id;
	}
	public void setOffer_Id(int offer_Id) {
		this.offer_Id = offer_Id;
	}
	public String getOffer_Name() {
		return offer_Name;
	}
	public void setOffer_Name(String offer_Name) {
		this.offer_Name = offer_Name;
	}
	public int getOffer_Discount() {
		return offer_Discount;
	}
	public void setOffer_Discount(int offer_Discount) {
		this.offer_Discount = offer_Discount;
	}
	public LocalDate getStart_Date() {
		return start_Date;
	}
	public void setStart_Date(LocalDate start_Date) {
		this.start_Date = start_Date;
	}
	public LocalDate getEnd_Date() {
		return end_Date;
	}
	public void setEnd_Date(LocalDate end_Date) {
		this.end_Date = end_Date;
	}
	public Offer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Offer(int offer_Id, String offer_Name, int offer_Discount, LocalDate start_Date, LocalDate end_Date) {
		super();
		this.offer_Id = offer_Id;
		this.offer_Name = offer_Name;
		this.offer_Discount = offer_Discount;
		this.start_Date = start_Date;
		this.end_Date = end_Date;
	}
	
	
	
}
