package com.virtusa.zomato.model;

public class Payment 
{
	private int payment_Id;
	private String payment_Type;
	private String payment_Status;
	private OrderDetails order_Details;
	private Customer customer;
	public int getPayment_Id() {
		return payment_Id;
	}
	public void setPayment_Id(int payment_Id) {
		this.payment_Id = payment_Id;
	}
	public String getPayment_Type() {
		return payment_Type;
	}
	public void setPayment_Type(String payment_Type) {
		this.payment_Type = payment_Type;
	}
	public String getPayment_Status() {
		return payment_Status;
	}
	public void setPayment_Status(String payment_Status) {
		this.payment_Status = payment_Status;
	}
	public OrderDetails getOrder_Details() {
		return order_Details;
	}
	public void setOrder_Details(OrderDetails order_Details) {
		this.order_Details = order_Details;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Payment [payment_Id=" + payment_Id + ", payment_Type=" + payment_Type + ", payment_Status="
				+ payment_Status + ", order_Details=" + order_Details + ", customer=" + customer + "]";
	}
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(int payment_Id, String payment_Type, String payment_Status, OrderDetails order_Details,
			Customer customer) {
		super();
		this.payment_Id = payment_Id;
		this.payment_Type = payment_Type;
		this.payment_Status = payment_Status;
		this.order_Details = order_Details;
		this.customer = customer;
	}
	
	
}
