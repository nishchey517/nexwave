package com.virtusa.zomato.model;

public class Menu 
{
	private int menu_Id;
	private String menu_Name;
	private float menu_Price;
	public Menu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Menu(int menu_Id, String menu_Name, float menu_Price) {
		super();
		this.menu_Id = menu_Id;
		this.menu_Name = menu_Name;
		this.menu_Price = menu_Price;
	}
	@Override
	public String toString() {
		return "Menu [menu_Id=" + menu_Id + ", menu_Name=" + menu_Name + ", menu_Price=" + menu_Price + "]";
	}
	public int getMenu_Id() {
		return menu_Id;
	}
	public void setMenu_Id(int menu_Id) {
		this.menu_Id = menu_Id;
	}
	public String getMenu_Name() {
		return menu_Name;
	}
	public void setMenu_Name(String menu_Name) {
		this.menu_Name = menu_Name;
	}
	public float getMenu_Price() {
		return menu_Price;
	}
	public void setMenu_Price(float menu_Price) {
		this.menu_Price = menu_Price;
	}
	
	
	
}
