package com.virtusa.zomato.model;

public class Delivery 
{
	private int delivery_Id;
	private String delivery_Name;
	private String delivery_Email;
	private String delivery_Address;
	private String delivery_Contact;
	public int getDelivery_Id() {
		return delivery_Id;
	}
	public void setDelivery_Id(int delivery_Id) {
		this.delivery_Id = delivery_Id;
	}
	public String getDelivery_Name() {
		return delivery_Name;
	}
	public void setDelivery_Name(String delivery_Name) {
		this.delivery_Name = delivery_Name;
	}
	public String getDelivery_Email() {
		return delivery_Email;
	}
	public void setDelivery_Email(String delivery_Email) {
		this.delivery_Email = delivery_Email;
	}
	public String getDelivery_Address() {
		return delivery_Address;
	}
	public void setDelivery_Address(String delivery_Address) {
		this.delivery_Address = delivery_Address;
	}
	public String getDelivery_Contact() {
		return delivery_Contact;
	}
	public void setDelivery_Contact(String delivery_Contact) {
		this.delivery_Contact = delivery_Contact;
	}
	@Override
	public String toString() {
		return "delivery [delivery_Id=" + delivery_Id + ", delivery_Name=" + delivery_Name + ", delivery_Email="
				+ delivery_Email + ", delivery_Address=" + delivery_Address + ", delivery_Contact=" + delivery_Contact
				+ "]";
	}
	public Delivery() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Delivery(int delivery_Id, String delivery_Name, String delivery_Email, String delivery_Address,
			String delivery_Contact) {
		super();
		this.delivery_Id = delivery_Id;
		this.delivery_Name = delivery_Name;
		this.delivery_Email = delivery_Email;
		this.delivery_Address = delivery_Address;
		this.delivery_Contact = delivery_Contact;
	}
	
	
	
}
