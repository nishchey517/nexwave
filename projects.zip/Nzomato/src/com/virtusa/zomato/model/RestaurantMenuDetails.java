package com.virtusa.zomato.model;

public class RestaurantMenuDetails 
{
	private int restaurantMenu_Id;
	private Menu menu;
	private Restaurant restaurant;
	public int getRestaurantMenu_Id() {
		return restaurantMenu_Id;
	}
	public void setRestaurantMenu_Id(int restaurantMenu_Id) {
		this.restaurantMenu_Id = restaurantMenu_Id;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	@Override
	public String toString() {
		return "RestaurantMenuDetails [restaurantMenu_Id=" + restaurantMenu_Id + ", menu=" + menu + ", restaurant="
				+ restaurant + "]";
	}
	public RestaurantMenuDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RestaurantMenuDetails(int restaurantMenu_Id, Menu menu, Restaurant restaurant) {
		super();
		this.restaurantMenu_Id = restaurantMenu_Id;
		this.menu = menu;
		this.restaurant = restaurant;
	}
	
	
	
}
