package com.virtusa.zomato.model;

public class OrderDetails 
{
	private int order_Id;
	private int order_Quantity;
	private String order_Status;
	private Restaurant restaurant;
	private Customer customer;
	private Menu menu;
	private Offer offer;
	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderDetails(int order_Id, int order_Quantity, String order_Status, Restaurant restaurant,
			Customer customer, Menu menu, Offer offer) {
		super();
		this.order_Id = order_Id;
		this.order_Quantity = order_Quantity;
		this.order_Status = order_Status;
		this.restaurant = restaurant;
		this.customer = customer;
		this.menu = menu;
		this.offer = offer;
	}
	@Override
	public String toString() {
		return "OrderDetails [order_Id=" + order_Id + ", order_Quantity=" + order_Quantity + ", order_Status="
				+ order_Status + ", restaurant=" + restaurant + ", customer=" + customer + ", menu=" + menu + ", offer="
				+ offer + "]";
	}
	public int getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}
	public int getOrder_Quantity() {
		return order_Quantity;
	}
	public void setOrder_Quantity(int order_Quantity) {
		this.order_Quantity = order_Quantity;
	}
	public String getOrder_Status() {
		return order_Status;
	}
	public void setOrder_Status(String order_Status) {
		this.order_Status = order_Status;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public Offer getOffer() {
		return offer;
	}
	public void setOffer(Offer offer) {
		this.offer = offer;
	}
	
	
	
}
