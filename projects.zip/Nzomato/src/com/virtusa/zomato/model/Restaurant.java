package com.virtusa.zomato.model;

public class Restaurant 
{
	
	private int restaurant_Id;
	private String restaurant_Name;
	private String restaurant_Email;
	private String restaurant_Address;
	private String restaurant_Contact;
	public Restaurant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Restaurant(int restaurant_Id, String restaurant_Name, String restaurant_Email, String restaurant_Address,
			String restaurant_Contact) {
		super();
		this.restaurant_Id = restaurant_Id;
		this.restaurant_Name = restaurant_Name;
		this.restaurant_Email = restaurant_Email;
		this.restaurant_Address = restaurant_Address;
		this.restaurant_Contact = restaurant_Contact;
	}
	@Override
	public String toString() {
		return "Restaurant [restaurant_Id=" + restaurant_Id + ", restaurant_Name=" + restaurant_Name
				+ ", restaurant_Email=" + restaurant_Email + ", restaurant_Address=" + restaurant_Address
				+ ", restaurant_Contact=" + restaurant_Contact + "]";
	}
	public int getRestaurant_Id() {
		return restaurant_Id;
	}
	public void setRestaurant_Id(int restaurant_Id) {
		this.restaurant_Id = restaurant_Id;
	}
	public String getRestaurant_Name() {
		return restaurant_Name;
	}
	public void setRestaurant_Name(String restaurant_Name) {
		this.restaurant_Name = restaurant_Name;
	}
	public String getRestaurant_Email() {
		return restaurant_Email;
	}
	public void setRestaurant_Email(String restaurant_Email) {
		this.restaurant_Email = restaurant_Email;
	}
	public String getRestaurant_Address() {
		return restaurant_Address;
	}
	public void setRestaurant_Address(String restaurant_Address) {
		this.restaurant_Address = restaurant_Address;
	}
	public String getRestaurant_Contact() {
		return restaurant_Contact;
	}
	public void setRestaurant_Contact(String restaurant_Contact) {
		this.restaurant_Contact = restaurant_Contact;
	}
	
	

}
