package com.virtusa.zomato.model;

import java.time.LocalDate;

public class Membership
{
	private int membership_Id;
	private LocalDate start_Date;
	private LocalDate end_Date;
	private String membership_Type;
	private Customer customer;
	public Membership() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMembership_Id() {
		return membership_Id;
	}
	public void setMembership_Id(int membership_Id) {
		this.membership_Id = membership_Id;
	}
	public LocalDate getStart_Date() {
		return start_Date;
	}
	public void setStart_Date(LocalDate start_Date) {
		this.start_Date = start_Date;
	}
	public LocalDate getEnd_Date() {
		return end_Date;
	}
	public void setEnd_Date(LocalDate end_Date) {
		this.end_Date = end_Date;
	}
	public String getMembership_Type() {
		return membership_Type;
	}
	public void setMembership_Type(String membership_Type) {
		this.membership_Type = membership_Type;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Membership(int membership_Id, LocalDate start_Date, LocalDate end_Date, String membership_Type,
			Customer customer) {
		super();
		this.membership_Id = membership_Id;
		this.start_Date = start_Date;
		this.end_Date = end_Date;
		this.membership_Type = membership_Type;
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Membership [membership_Id=" + membership_Id + ", start_Date=" + start_Date + ", end_Date=" + end_Date
				+ ", membership_Type=" + membership_Type + ", customer=" + customer + "]";
	}
	
	
	
}
