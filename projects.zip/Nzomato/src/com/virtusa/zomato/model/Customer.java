package com.virtusa.zomato.model;

public class Customer
{
	private int customer_Id;
	private String customer_Name;
	private String customer_Email;
	private String customer_Address;
	private String customer_Contact;
	public int getCustomer_Id() {
		return customer_Id;
	}
	public void setCustomer_Id(int customer_Id) {
		this.customer_Id = customer_Id;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getCustomer_Email() {
		return customer_Email;
	}
	public void setCustomer_Email(String customer_Email) {
		this.customer_Email = customer_Email;
	}
	public String getCustomer_Address() {
		return customer_Address;
	}
	public void setCustomer_Address(String customer_Address) {
		this.customer_Address = customer_Address;
	}
	public String getCustomer_Contact() {
		return customer_Contact;
	}
	public void setCustomer_Contact(String customer_Contact) {
		this.customer_Contact = customer_Contact;
	}
	@Override
	public String toString() {
		return "customer [customer_Id=" + customer_Id + ", customer_Name=" + customer_Name + ", customer_Email="
				+ customer_Email + ", customer_Address=" + customer_Address + ", customer_Contact=" + customer_Contact
				+ "]";
	}
	public Customer(int customer_Id, String customer_Name, String customer_Email, String customer_Address,
			String customer_Contact) {
		super();
		this.customer_Id = customer_Id;
		this.customer_Name = customer_Name;
		this.customer_Email = customer_Email;
		this.customer_Address = customer_Address;
		this.customer_Contact = customer_Contact;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
