package com.virtusa.collegeportal.app;

import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.collegeportal.dao.ApplicantDao;
import com.virtusa.collegeportal.dao.StudentDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Applicant;
import com.virtusa.collegeportal.model.ClassRoom;
import com.virtusa.collegeportal.model.ClassSchedule;
import com.virtusa.collegeportal.model.CourseOffered;
import com.virtusa.collegeportal.model.LoginDetail;
//import com.virtusa.zomato.exception.ZomatoException;
import com.virtusa.collegeportal.model.Student;
import com.virtusa.collegeportal.util.ClassScheduleUtil;
import com.virtusa.collegeportal.util.ConnectionUtil;
import com.virtusa.collegeportal.util.NewsAndEventsUtil;

public class Main {

	public static void main(String[] args) throws CollegePortalException {

		try{
			
			Connection d=ConnectionUtil.getConnection();
			System.out.println(d);
		ClassScheduleUtil app= new ClassScheduleUtil();
		
		List<ClassSchedule> ar=(ArrayList)app.checkClassSchedule();
		System.out.println(ar);


	}
		catch (CollegePortalException e2) {
			
			System.out.println(e2.getMessage());

}
}}