package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//import com.virtusa.collegeportal.dao.Logger;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Examination;
//import com.virtusa.collegeportal.model.Examination;
//import com.virtusa.collegeportal.model.Student;
public class ExaminationUtil {
Logger logger = Logger.getLogger("Examination");

public List<Examination> checkExamination() throws CollegePortalException {
// TODO Auto-generated method stub
String query = "select * from examination ";

List<Examination> list=new ArrayList<>();
ResultSet resultSet = null;
Connection connection = ConnectionUtil.getConnection();
PreparedStatement preparedStatement = null;
try {
System.out.println(connection);
preparedStatement = connection.prepareStatement(query);	
resultSet = preparedStatement.executeQuery();

while (resultSet.next()) {

int examId = resultSet.getInt("ex_id");
String examSubject = resultSet.getString("ex_subject");
Date examStartDate=resultSet.getDate("examStartDate");

Date examEndDate=resultSet.getDate("examEndDate");

Examination examination = new Examination();

examination.setExamId(examId);
examination.setExamSubject(examSubject);
examination.setExamStartDate(examStartDate) ;
   examination.setExamEndDate(examEndDate);
                list.add(examination);
}

} catch (SQLException e) {
// TODO Auto-generated catch block
logger.error("sql error", e);
throw new CollegePortalException(e.getMessage());
} catch (Exception e) {
// TODO Auto-generated catch block
logger.error("internal error", e);
throw new CollegePortalException(e.getMessage());
}

finally {


try {

if (resultSet != null) {

resultSet.close();
}

if (preparedStatement != null) {
preparedStatement.close();
}

if (connection != null) {
connection.close();
}
} catch (SQLException e) {

logger.error("sql error", e);
// TODO: handle exception
throw new CollegePortalException(" error while closing a resource contact to admin");

} catch (Exception e) {
// TODO: handle exception.

logger.error("internal error", e);
throw new CollegePortalException("  contact to admin");

}

}

// TODO Auto-generated method stub
System.out.println(list.toString());
return list;
}
}
