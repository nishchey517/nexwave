package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.exception.CollegePortalException;
//import com.virtusa.collegeportal.model.Alumini;
import com.virtusa.collegeportal.model.LoginDetail;

public class Login {

	public Login() {
		// TODO Auto-generated constructor stub
		
		
	}
	
	
	Logger logger = Logger.getLogger("AluminiDAO");

	public int doLoginCheck(LoginDetail loginDetail) throws CollegePortalException {
		// TODO Auto-generated method stub
		int flag = 0;
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = connection
					.prepareStatement("select username ,password,usertype  " + "from login where username=? and password=? and usertype=?");
			preparedStatement.setString(1, loginDetail.getUserId());

			preparedStatement.setString(2, loginDetail.getPassword());
			preparedStatement.setString(3, loginDetail.getUsertype());
			
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				flag = 1;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("error with SQL", e);
			throw new CollegePortalException("Some internal error contact to admin");
		} catch (Exception exception) {

			logger.error("error with system", exception);
			throw new CollegePortalException("Some internal error contact to admin");

		}

		finally {

			// close pstmt,connection,result set also
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				// TODO: handle exception
				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}
		return flag;
	}
 

}
