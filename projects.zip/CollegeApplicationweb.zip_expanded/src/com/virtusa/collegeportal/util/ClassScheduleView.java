package com.virtusa.collegeportal.util;

public class ClassScheduleView {
	
	int ClassId;
	String subject;
	public ClassScheduleView(int classId, String subject, String facultyName, String time) {
		super();
		ClassId = classId;
		this.subject = subject;
		this.facultyName = facultyName;
		this.time = time;
	}
	public ClassScheduleView() {
		super();
	}
	@Override
	public String toString() {
		return "ClassScheduleView [ClassId=" + ClassId + ", subject=" + subject + ", facultyName=" + facultyName
				+ ", time=" + time + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ClassId;
		result = prime * result + ((facultyName == null) ? 0 : facultyName.hashCode());
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClassScheduleView other = (ClassScheduleView) obj;
		if (ClassId != other.ClassId)
			return false;
		if (facultyName == null) {
			if (other.facultyName != null)
				return false;
		} else if (!facultyName.equals(other.facultyName))
			return false;
		if (subject == null) {
			if (other.subject != null)
				return false;
		} else if (!subject.equals(other.subject))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		return true;
	}
	public int getClassId() {
		return ClassId;
	}
	public void setClassId(int classId) {
		ClassId = classId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	String facultyName;
	String time;
	

}
