package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.mysql.jdbc.Statement;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Assignment;

public class AssignmentUtil {

	public AssignmentUtil() {
	}

	
	
	Logger logger = Logger.getLogger("AssignmentUtil");
	
	public int uploadAssignment(Assignment assignment) throws CollegePortalException {
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		
		try {
		preparedStatement=connection.prepareStatement("insert into assignment(as_name,as_link,as_description,as_f_id,as_su_name) values(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
	
		preparedStatement.setString(1,assignment.getAssignmentName());
		preparedStatement.setString(2,assignment.getAssignmentLink());
		preparedStatement.setString(3,assignment.getAssignmentDescription());
		preparedStatement.setInt(4,assignment.getFacultyId());
		preparedStatement.setString(5, assignment.getSubject());

		            return preparedStatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("error with SQL", e);
			throw new CollegePortalException("Some internal error contact to admin");
		} catch (Exception exception) {
			logger.error("error with system", exception);
			throw new CollegePortalException("Some internal error contact to admin");

		}

		finally {

			// close pstmt,connection,result set also
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}
		

	
	}
	
	public List<AssignmentView> downloadAssignment() throws CollegePortalException {
		// TODO Auto-generated method stub
		String query = "select a.as_id, a.as_name,a.as_link,f.f_name,a.as_su_name from assignment a join faculty f on a.as_f_id=f.f_id";
				
				List<AssignmentView> list=new ArrayList<>();
				ResultSet resultSet = null;
				Connection connection = ConnectionUtil.getConnection();
				PreparedStatement preparedStatement = null;
				try {
					System.out.println(connection);
					preparedStatement = connection.prepareStatement(query);	
					resultSet = preparedStatement.executeQuery();
				
					while (resultSet.next()) {

						int assignmentId = resultSet.getInt("as_id");
						String assignmentName = resultSet.getString("as_name");
						String facultyName = resultSet.getString("f_name");
						String link = resultSet.getString("as_link");
						String subject = resultSet.getString("as_su_name");
					

						AssignmentView assignmentView = new AssignmentView(assignmentId,assignmentName,link,facultyName,subject);

		                 list.add(assignmentView);
					}
					System.out.println(list);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					logger.error("sql error", e);
					throw new CollegePortalException(e.getMessage());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("internal error", e);
					throw new CollegePortalException(e.getMessage());
				}

				finally {

					
					try {

						if (resultSet != null) {

							resultSet.close();
						}

						if (preparedStatement != null) {
							preparedStatement.close();
						}

						if (connection != null) {
							connection.close();
						}
					} catch (SQLException e) {

						logger.error("sql error", e);
						// TODO: handle exception
						throw new CollegePortalException(" error while closing a resource contact to admin");

					} catch (Exception e) {
						// TODO: handle exception.

						logger.error("internal error", e);
						throw new CollegePortalException("  contact to admin");

					}

				}

				// TODO Auto-generated method stub
				return list;

}
}
