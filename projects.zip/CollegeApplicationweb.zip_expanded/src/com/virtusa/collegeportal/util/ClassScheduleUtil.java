package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.exception.CollegePortalException;

public class ClassScheduleUtil {
	Logger logger = Logger.getLogger("classSchedule");

	public List<ClassScheduleView> checkClassSchedule() throws CollegePortalException {
		// TODO Auto-generated method stub
		String query = "select * from class_schedule";
				
				List<ClassScheduleView> list=new ArrayList<>();
				ResultSet resultSet = null;
				Connection connection = ConnectionUtil.getConnection();
				PreparedStatement preparedStatement = null;
				try {
					System.out.println(connection);
					preparedStatement = connection.prepareStatement(query);	
					resultSet = preparedStatement.executeQuery();
				
					while (resultSet.next()) {

						int classId = resultSet.getInt("cs_cl_id");
						String facultyName = resultSet.getString("cs_faculty");
						String time = resultSet.getString("cs_timing");
						String subject = resultSet.getString("cs_subject");
					

						ClassScheduleView classSchedule = new ClassScheduleView(classId,subject,facultyName,time);

		                 list.add(classSchedule);
					}
					System.out.println(list);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					logger.error("sql error", e);
					throw new CollegePortalException(e.getMessage());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("internal error", e);
					throw new CollegePortalException(e.getMessage());
				}

				finally {

					
					try {

						if (resultSet != null) {

							resultSet.close();
						}

						if (preparedStatement != null) {
							preparedStatement.close();
						}

						if (connection != null) {
							connection.close();
						}
					} catch (SQLException e) {

						logger.error("sql error", e);
						// TODO: handle exception
						throw new CollegePortalException(" error while closing a resource contact to admin");

					} catch (Exception e) {
						// TODO: handle exception.

						logger.error("internal error", e);
						throw new CollegePortalException("  contact to admin");

					}

				}

				// TODO Auto-generated method stub
				return list;

	
	

}}