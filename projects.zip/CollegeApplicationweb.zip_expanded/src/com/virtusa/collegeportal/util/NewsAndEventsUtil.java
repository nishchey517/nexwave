package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

//import com.virtusa.collegeportal.dao.Logger;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.NewsAndEvents;

public class NewsAndEventsUtil {
Logger logger = Logger.getLogger("newsAndEvents");

public List<NewsAndEvents> checkNewsAndEvents() throws CollegePortalException {

	String query = "select * from news_and_events ";
			
			List<NewsAndEvents> list=new ArrayList<>();
			ResultSet resultSet = null;
			Connection connection = ConnectionUtil.getConnection();
			PreparedStatement preparedStatement = null;
			try {
				System.out.println(connection);
				preparedStatement = connection.prepareStatement(query);	
				resultSet = preparedStatement.executeQuery();
			
				while (resultSet.next()) {

					int eventId = resultSet.getInt("ne_id");
					String eventName = resultSet.getString("ne_name");
					Date eventDate=resultSet.getDate("ne_Date");

					NewsAndEvents newsAndEvents = new NewsAndEvents();

					newsAndEvents.setEventName(eventName);;
					newsAndEvents.setEventId(eventId);
					newsAndEvents.setEventDate(eventDate);
	                 list.add(newsAndEvents);
				}

			} catch (SQLException e) {

				logger.error("sql error", e);
				throw new CollegePortalException(e.getMessage());
			} catch (Exception e) {

				logger.error("internal error", e);
				throw new CollegePortalException(e.getMessage());
			}

			finally {

				
				try {

					if (resultSet != null) {

						resultSet.close();
					}

					if (preparedStatement != null) {
						preparedStatement.close();
					}

					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {

					logger.error("sql error", e);

					throw new CollegePortalException(" error while closing a resource contact to admin");

				} catch (Exception e) {


					logger.error("internal error", e);
					throw new CollegePortalException("  contact to admin");

				}

			}

			return list;
}
}