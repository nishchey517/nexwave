package com.virtusa.collegeportal.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.exception.CollegePortalException;

public class ConnectionUtil {
	public ConnectionUtil() {
		
	}
	
	private static Logger logger=Logger.getLogger("ConnectionUtil");
	
	public static Connection getConnection() throws CollegePortalException{

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			logger.error("driver error", e);
		 throw new CollegePortalException("Driver is not available ");		
		}
       Connection connection=null;;
try {
	connection = DriverManager.getConnection("jdbc:mysql://localhost/college_portal", "root", "root");
} catch (SQLException e) {
	// TODO Auto-generated catch block
	logger.error("SQL  error", e);
	e.printStackTrace();
	
	throw new CollegePortalException("Connection is not avaialble ");
}	
		return connection;
			
	}
	
	
	
	

}
