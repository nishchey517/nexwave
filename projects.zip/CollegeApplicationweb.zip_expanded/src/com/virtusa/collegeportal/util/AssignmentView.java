package com.virtusa.collegeportal.util;

public class AssignmentView {

	public AssignmentView() {
		// TODO Auto-generated constructor stub
	}
	
	
	int assignmentId;
	String assignmentName;
	String assignmentLink;
	String facultyName;
	String subject;
	public int getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getAssignmentName() {
		return assignmentName;
	}
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}
	public String getAssignmentLink() {
		return assignmentLink;
	}
	public void setAssignmentLink(String assignmentLink) {
		this.assignmentLink = assignmentLink;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "AssignmentView [assignmentId=" + assignmentId + ", assignmentName=" + assignmentName
				+ ", assignmentLink=" + assignmentLink + ", facultyName=" + facultyName + ", subject=" + subject + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + assignmentId;
		result = prime * result + ((assignmentLink == null) ? 0 : assignmentLink.hashCode());
		result = prime * result + ((assignmentName == null) ? 0 : assignmentName.hashCode());
		result = prime * result + ((facultyName == null) ? 0 : facultyName.hashCode());
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AssignmentView other = (AssignmentView) obj;
		if (assignmentId != other.assignmentId)
			return false;
		if (assignmentLink == null) {
			if (other.assignmentLink != null)
				return false;
		} else if (!assignmentLink.equals(other.assignmentLink))
			return false;
		if (assignmentName == null) {
			if (other.assignmentName != null)
				return false;
		} else if (!assignmentName.equals(other.assignmentName))
			return false;
		if (facultyName == null) {
			if (other.facultyName != null)
				return false;
		} else if (!facultyName.equals(other.facultyName))
			return false;
		if (subject == null) {
			if (other.subject != null)
				return false;
		} else if (!subject.equals(other.subject))
			return false;
		return true;
	}
	public AssignmentView(int assignmentId, String assignmentName, String assignmentLink, String facultyName,
			String subject) {
		super();
		this.assignmentId = assignmentId;
		this.assignmentName = assignmentName;
		this.assignmentLink = assignmentLink;
		this.facultyName = facultyName;
		this.subject = subject;
	}


}
