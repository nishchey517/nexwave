package com.virtusa.collegeportal.util;

public class AluminiView {
	String al_name;
	Long al_contact;
	
	public String getAl_name() {
		return al_name;
	}
	public void setAl_name(String al_name) {
		this.al_name = al_name;
	}
	public Long getAl_contact() {
		return al_contact;
	}
	public void setAl_contact(Long al_contact) {
		this.al_contact = al_contact;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((al_contact == null) ? 0 : al_contact.hashCode());
		result = prime * result + ((al_name == null) ? 0 : al_name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AluminiView other = (AluminiView) obj;
		if (al_contact == null) {
			if (other.al_contact != null)
				return false;
		} else if (!al_contact.equals(other.al_contact))
			return false;
		
		if (al_name == null) {
			if (other.al_name != null)
				return false;
		} else if (!al_name.equals(other.al_name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AluminiView [al_name=" + al_name + ", al_contact=" + al_contact +   "]";
	}
	public AluminiView(String al_name, Long al_contact) {
		super();
		this.al_name = al_name;
		this.al_contact = al_contact;
		
	}
	public AluminiView() {
		super();
	}
	
	
}
