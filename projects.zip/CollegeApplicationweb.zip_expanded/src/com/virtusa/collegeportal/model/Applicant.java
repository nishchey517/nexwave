package com.virtusa.collegeportal.model;

public class Applicant {

	public Applicant() {

	}
	private int applicantId;
	private String applicantName;
	private String applicationGender;
	private String applicantEmail;
	private String applicantStatus;
	private Long applicantContact;
	private int applicantRank;
	private String applicantCourse;
	public int getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public String getApplicationGender() {
		return applicationGender;
	}
	public void setApplicationGender(String applicationGender) {
		this.applicationGender = applicationGender;
	}
	public String getApplicantEmail() {
		return applicantEmail;
	}
	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}
	public String getApplicantStatus() {
		return applicantStatus;
	}
	public void setApplicantStatus(String applicantStatus) {
		this.applicantStatus = applicantStatus;
	}
	public Long getApplicantContact() {
		return applicantContact;
	}
	public void setApplicantContact(Long applicantContact) {
		this.applicantContact = applicantContact;
	}
	public int getApplicantRank() {
		return applicantRank;
	}
	public void setApplicantRank(int applicantRank) {
		this.applicantRank = applicantRank;
	}
	public String getApplicantCourse() {
		return applicantCourse;
	}
	public void setApplicantCourse(String applicantCourse) {
		this.applicantCourse = applicantCourse;
	}
	public Applicant(String applicantName, String applicationGender, String applicantEmail,
			Long applicantContact, int applicantRank, String applicantCourse) {
		super();
		this.applicantId = applicantId;
		this.applicantName = applicantName;
		this.applicationGender = applicationGender;
		this.applicantEmail = applicantEmail;
		this.applicantStatus = applicantStatus;
		this.applicantContact = applicantContact;
		this.applicantRank = applicantRank;
		this.applicantCourse = applicantCourse;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((applicantContact == null) ? 0 : applicantContact.hashCode());
		result = prime * result + ((applicantCourse == null) ? 0 : applicantCourse.hashCode());
		result = prime * result + ((applicantEmail == null) ? 0 : applicantEmail.hashCode());
		result = prime * result + applicantId;
		result = prime * result + ((applicantName == null) ? 0 : applicantName.hashCode());
		result = prime * result + applicantRank;
		result = prime * result + ((applicantStatus == null) ? 0 : applicantStatus.hashCode());
		result = prime * result + ((applicationGender == null) ? 0 : applicationGender.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Applicant other = (Applicant) obj;
		if (applicantContact == null) {
			if (other.applicantContact != null)
				return false;
		} else if (!applicantContact.equals(other.applicantContact))
			return false;
		if (applicantCourse == null) {
			if (other.applicantCourse != null)
				return false;
		} else if (!applicantCourse.equals(other.applicantCourse))
			return false;
		if (applicantEmail == null) {
			if (other.applicantEmail != null)
				return false;
		} else if (!applicantEmail.equals(other.applicantEmail))
			return false;
		if (applicantId != other.applicantId)
			return false;
		if (applicantName == null) {
			if (other.applicantName != null)
				return false;
		} else if (!applicantName.equals(other.applicantName))
			return false;
		if (applicantRank != other.applicantRank)
			return false;
		if (applicantStatus == null) {
			if (other.applicantStatus != null)
				return false;
		} else if (!applicantStatus.equals(other.applicantStatus))
			return false;
		if (applicationGender == null) {
			if (other.applicationGender != null)
				return false;
		} else if (!applicationGender.equals(other.applicationGender))
			return false;
		return true;
	}
	
}
