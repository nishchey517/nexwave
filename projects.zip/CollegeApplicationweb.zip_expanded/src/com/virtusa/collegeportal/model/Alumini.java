package com.virtusa.collegeportal.model;

public class Alumini {

	public Alumini() {

	}
	private float alumniId;
	private String alumniName;
	private Student student;
	public float getAlumniId() {
		return alumniId;
	}
	public void setAlumniId(float alumniId) {
		this.alumniId = alumniId;
	}
	public String getAlumniName() {
		return alumniName;
	}
	public void setAlumniName(String alumniName) {
		this.alumniName = alumniName;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(alumniId);
		result = prime * result + ((alumniName == null) ? 0 : alumniName.hashCode());
		result = prime * result + ((student == null) ? 0 : student.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumini other = (Alumini) obj;
		if (Float.floatToIntBits(alumniId) != Float.floatToIntBits(other.alumniId))
			return false;
		if (alumniName == null) {
			if (other.alumniName != null)
				return false;
		} else if (!alumniName.equals(other.alumniName))
			return false;
		if (student == null) {
			if (other.student != null)
				return false;
		} else if (!student.equals(other.student))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Alumini [alumniId=" + alumniId + ", alumniName=" + alumniName + ", student=" + student + "]";
	}
	public Alumini(float alumniId, String alumniName, Student student) {
		super();
		this.alumniId = alumniId;
		this.alumniName = alumniName;
		this.student = student;
	}
		
}
