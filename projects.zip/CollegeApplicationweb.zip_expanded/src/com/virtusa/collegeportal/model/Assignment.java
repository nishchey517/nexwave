package com.virtusa.collegeportal.model;

public class Assignment {
private Faculty faculty;
private String assignmentLink;
private String assignmentName;
private String assignmentDescription;
private String subject;
private int facultyId;
public Faculty getFaculty() {
	return faculty;
}
public void setFaculty(Faculty faculty) {
	this.faculty = faculty;
}
public String getAssignmentLink() {
	return assignmentLink;
}
public void setAssignmentLink(String assignmentLink) {
	this.assignmentLink = assignmentLink;
}
public String getAssignmentName() {
	return assignmentName;
}
public void setAssignmentName(String assignmentName) {
	this.assignmentName = assignmentName;
}
public String getAssignmentDescription() {
	return assignmentDescription;
}
public void setAssignmentDescription(String assignmentDescription) {
	this.assignmentDescription = assignmentDescription;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public int getFacultyId() {
	return facultyId;
}
public void setFacultyId(int facultyId) {
	this.facultyId = facultyId;
}
@Override
public String toString() {
	return "Assignment [faculty=" + faculty+ ", assignmentLink=" + assignmentLink + ", assignmentName="
			+ assignmentName + ", assignmentDescription=" + assignmentDescription + ", subject=" + subject
			+ ", facultyId=" + facultyId + "]";
}
public Assignment(String assignmentLink, String assignmentName, String assignmentDescription, String subject,
		int facultyId) {
	super();
	this.assignmentLink = assignmentLink;
	this.assignmentName = assignmentName;
	this.assignmentDescription = assignmentDescription;
	this.subject = subject;
	this.facultyId = facultyId;
}


}
