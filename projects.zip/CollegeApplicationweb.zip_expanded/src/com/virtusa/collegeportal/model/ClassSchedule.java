package com.virtusa.collegeportal.model;

public class ClassSchedule {

	public ClassSchedule() {

	}
	private int classScheduleId;
	private ClassRoom classRoomId;  
	private String time; 
	private String subjectId;
	private Faculty facultyId;
	public int getClassScheduleId() {
		return classScheduleId;
	}
	public void setClassScheduleId(int classScheduleId) {
		this.classScheduleId = classScheduleId;
	}
	public ClassRoom getClassRoomId() {
		return classRoomId;
	}
	public void setClassRoomId(ClassRoom classRoomId) {
		this.classRoomId = classRoomId;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public ClassSchedule(int classScheduleId, ClassRoom classRoomId, String time, String subjectId, Faculty facultyId) {
		super();
		this.classScheduleId = classScheduleId;
		this.classRoomId = classRoomId;
		this.time = time;
		this.subjectId = subjectId;
		this.facultyId = facultyId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((classRoomId == null) ? 0 : classRoomId.hashCode());
		result = prime * result + classScheduleId;
		result = prime * result + ((facultyId == null) ? 0 : facultyId.hashCode());
		result = prime * result + ((subjectId == null) ? 0 : subjectId.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		return result;
	}
	@Override
	public String toString() {
		return "ClassSchedule [classScheduleId=" + classScheduleId + ", classRoomId=" + classRoomId + ", time=" + time
				+ ", subjectId=" + subjectId + ", facultyId=" + facultyId + "]";
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClassSchedule other = (ClassSchedule) obj;
		if (classRoomId == null) {
			if (other.classRoomId != null)
				return false;
		} else if (!classRoomId.equals(other.classRoomId))
			return false;
		if (classScheduleId != other.classScheduleId)
			return false;
		if (facultyId == null) {
			if (other.facultyId != null)
				return false;
		} else if (!facultyId.equals(other.facultyId))
			return false;
		if (subjectId == null) {
			if (other.subjectId != null)
				return false;
		} else if (!subjectId.equals(other.subjectId))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		return true;
	}
	public Faculty getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(Faculty facultyId) {
		this.facultyId = facultyId;
	}

}
