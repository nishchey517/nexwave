package com.virtusa.collegeportal.model;

public class Faculty {

	public Faculty() {

	}
private int facultyId;
private String facultyName;
private float facultyContact;
private String facultyEmail;

private ClassRoom classroom;
public Faculty(int facultyId, String facultyName, float facultyContact, String facultyEmail, ClassRoom classroom) {
	super();
	this.facultyId = facultyId;
	this.facultyName = facultyName;
	this.facultyContact = facultyContact;
	this.facultyEmail = facultyEmail;
	this.classroom = classroom;
}
@Override
public String toString() {
	return "Faculty [facultyId=" + facultyId + ", facultyName=" + facultyName + ", facultyContact=" + facultyContact
			+ ", facultyEmail=" + facultyEmail + ", classroom=" + classroom + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((classroom == null) ? 0 : classroom.hashCode());
	result = prime * result + Float.floatToIntBits(facultyContact);
	result = prime * result + ((facultyEmail == null) ? 0 : facultyEmail.hashCode());
	result = prime * result + facultyId;
	result = prime * result + ((facultyName == null) ? 0 : facultyName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Faculty other = (Faculty) obj;
	if (classroom == null) {
		if (other.classroom != null)
			return false;
	} else if (!classroom.equals(other.classroom))
		return false;
	if (Float.floatToIntBits(facultyContact) != Float.floatToIntBits(other.facultyContact))
		return false;
	if (facultyEmail == null) {
		if (other.facultyEmail != null)
			return false;
	} else if (!facultyEmail.equals(other.facultyEmail))
		return false;
	if (facultyId != other.facultyId)
		return false;
	if (facultyName == null) {
		if (other.facultyName != null)
			return false;
	} else if (!facultyName.equals(other.facultyName))
		return false;
	return true;
}
public int getFacultyId() {
	return facultyId;
}
public void setFacultyId(int facultyId) {
	this.facultyId = facultyId;
}
public String getFacultyName() {
	return facultyName;
}
public void setFacultyName(String facultyName) {
	this.facultyName = facultyName;
}
public float getFacultyContact() {
	return facultyContact;
}
public void setFacultyContact(float facultyContact) {
	this.facultyContact = facultyContact;
}
public String getFacultyEmail() {
	return facultyEmail;
}
public void setFacultyEmail(String facultyEmail) {
	this.facultyEmail = facultyEmail;
}
public ClassRoom getClassroom() {
	return classroom;
}
public void setClassroom(ClassRoom classroom) {
	this.classroom = classroom;
}

}
