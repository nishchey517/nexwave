package com.virtusa.collegeportal.model;

public class StudentPlacement {

	public StudentPlacement() {
	}
	private int studentportalId;
	private Placement placement;
	private Student student;
	public int getStudentportalId() {
		return studentportalId;
	}
	public void setStudentportalId(int studentportalId) {
		this.studentportalId = studentportalId;
	}
	public Placement getPlacement() {
		return placement;
	}
	public void setPlacement(Placement placement) {
		this.placement = placement;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	@Override
	public String toString() {
		return "StudentPlacement [studentportalId=" + studentportalId + ", placement=" + placement + ", student="
				+ student + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((placement == null) ? 0 : placement.hashCode());
		result = prime * result + ((student == null) ? 0 : student.hashCode());
		result = prime * result + studentportalId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentPlacement other = (StudentPlacement) obj;
		if (placement == null) {
			if (other.placement != null)
				return false;
		} else if (!placement.equals(other.placement))
			return false;
		if (student == null) {
			if (other.student != null)
				return false;
		} else if (!student.equals(other.student))
			return false;
		if (studentportalId != other.studentportalId)
			return false;
		return true;
	}
	
	

}
