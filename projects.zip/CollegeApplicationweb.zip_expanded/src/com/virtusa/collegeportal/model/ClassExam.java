package com.virtusa.collegeportal.model;

public class ClassExam {

	public ClassExam() {

	}
private int classExamId;
private ClassRoom classRoom;
private Examination examination;
public int getClassExamId() {
	return classExamId;
}
public void setClassExamId(int classExamId) {
	this.classExamId = classExamId;
}
public ClassRoom getClassRoom() {
	return classRoom;
}
public void setClassRoom(ClassRoom classRoom) {
	this.classRoom = classRoom;
}
public Examination getExamination() {
	return examination;
}
public void setExamination(Examination examination) {
	this.examination = examination;
}
@Override
public String toString() {
	return "ClassExam [classExamId=" + classExamId + ", classRoom=" + classRoom + ", examination=" + examination + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + classExamId;
	result = prime * result + ((classRoom == null) ? 0 : classRoom.hashCode());
	result = prime * result + ((examination == null) ? 0 : examination.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ClassExam other = (ClassExam) obj;
	if (classExamId != other.classExamId)
		return false;
	if (classRoom == null) {
		if (other.classRoom != null)
			return false;
	} else if (!classRoom.equals(other.classRoom))
		return false;
	if (examination == null) {
		if (other.examination != null)
			return false;
	} else if (!examination.equals(other.examination))
		return false;
	return true;
}

}
