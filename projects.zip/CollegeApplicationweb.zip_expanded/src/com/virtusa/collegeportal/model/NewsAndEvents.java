package com.virtusa.collegeportal.model;

import java.sql.Date;

public class NewsAndEvents {

	public NewsAndEvents() {

	}
public NewsAndEvents(int eventId, Date eventDate, String eventName) {
		super();
		this.eventId = eventId;
		EventDate = eventDate;
		this.eventName = eventName;
	}
private int eventId;
private Date EventDate;
private String eventName;
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public Date getEventDate() {
	return EventDate;
}
public void setEventDate(Date eventDate2) {
	EventDate = eventDate2;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
@Override
public String toString() {
	return "NewsAndEvents [eventId=" + eventId + ", EventDate=" + EventDate + ", eventName=" + eventName + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((EventDate == null) ? 0 : EventDate.hashCode());
	result = prime * result + eventId;
	result = prime * result + ((eventName == null) ? 0 : eventName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	NewsAndEvents other = (NewsAndEvents) obj;
	if (EventDate == null) {
		if (other.EventDate != null)
			return false;
	} else if (!EventDate.equals(other.EventDate))
		return false;
	if (eventId != other.eventId)
		return false;
	if (eventName == null) {
		if (other.eventName != null)
			return false;
	} else if (!eventName.equals(other.eventName))
		return false;
	return true;
}


}
