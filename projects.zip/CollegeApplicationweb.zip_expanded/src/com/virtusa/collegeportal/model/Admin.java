package com.virtusa.collegeportal.model;

public class Admin {

	public Admin() {

	}

	private int adminId;
	private String adminName;
	private int adminPassword;
	private String adminEmail;
	private int adminContact;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adminContact;
		result = prime * result + ((adminEmail == null) ? 0 : adminEmail.hashCode());
		result = prime * result + adminId;
		result = prime * result + ((adminName == null) ? 0 : adminName.hashCode());
		result = prime * result + adminPassword;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Admin other = (Admin) obj;
		if (adminContact != other.adminContact)
			return false;
		if (adminEmail == null) {
			if (other.adminEmail != null)
				return false;
		} else if (!adminEmail.equals(other.adminEmail))
			return false;
		if (adminId != other.adminId)
			return false;
		if (adminName == null) {
			if (other.adminName != null)
				return false;
		}
		else if (!adminName.equals(other.adminName))
			return false;
		if (adminPassword != other.adminPassword)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", adminPassword=" + adminPassword
				+ ", adminEmail=" + adminEmail + ", adminContact=" + adminContact + "]";
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public int getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(int adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public int getAdminContact() {
		return adminContact;
	}

	public void setAdminContact(int adminContact) {
		this.adminContact = adminContact;
	}
}
