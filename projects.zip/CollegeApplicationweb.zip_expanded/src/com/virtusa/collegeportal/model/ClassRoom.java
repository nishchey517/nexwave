package com.virtusa.collegeportal.model;

public class ClassRoom {

	public ClassRoom() {

	}
	private int classId;
	private int classStrength;
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getClassStrength() {
		return classStrength;
	}
	public void setClassStrength(int classStrength) {
		this.classStrength = classStrength;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + classId;
		result = prime * result + classStrength;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClassRoom other = (ClassRoom) obj;
		if (classId != other.classId)
			return false;
		if (classStrength != other.classStrength)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ClassRoom [classId=" + classId + ", classStrength=" + classStrength + "]";
	}
	public ClassRoom(int classId, int classStrength) {
		super();
		this.classId = classId;
		this.classStrength = classStrength;
	}
	
}
