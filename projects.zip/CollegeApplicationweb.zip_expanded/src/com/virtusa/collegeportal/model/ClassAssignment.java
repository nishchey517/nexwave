package com.virtusa.collegeportal.model;

public class ClassAssignment {

	public ClassAssignment() {

	}
private int classAssignmentId;
private ClassRoom classroom;
private Assignment assignment;
public int getClassAssignmentId() {
	return classAssignmentId;
}
public void setClassAssignmentId(int classAssignmentId) {
	this.classAssignmentId = classAssignmentId;
}
public ClassRoom getClassroom() {
	return classroom;
}
public void setClassroom(ClassRoom classroom) {
	this.classroom = classroom;
}
public Assignment getAssignment() {
	return assignment;
}
public void setAssignment(Assignment assignment) {
	this.assignment = assignment;
}
@Override
public String toString() {
	return "ClassAssignment [classAssignmentId=" + classAssignmentId + ", classroom=" + classroom + ", assignment="
			+ assignment + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((assignment == null) ? 0 : assignment.hashCode());
	result = prime * result + classAssignmentId;
	result = prime * result + ((classroom == null) ? 0 : classroom.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ClassAssignment other = (ClassAssignment) obj;
	if (assignment == null) {
		if (other.assignment != null)
			return false;
	} else if (!assignment.equals(other.assignment))
		return false;
	if (classAssignmentId != other.classAssignmentId)
		return false;
	if (classroom == null) {
		if (other.classroom != null)
			return false;
	} else if (!classroom.equals(other.classroom))
		return false;
	return true;
}

}
