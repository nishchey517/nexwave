package com.virtusa.collegeportal.model;

import java.sql.Date;


public class Examination {

	public Examination() {

	}
	private int examId;
	private Date examStartDate;
	private Date examEndDate;
	private String examSubject;
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public Date getExamStartDate() {
		return examStartDate;
	}
	public void setExamStartDate(Date examStartDate) {
		this.examStartDate = examStartDate;
	}
	public Date getExamEndDate() {
		return examEndDate;
	}
	public void setExamEndDate(Date examEndDate) {
		this.examEndDate = examEndDate;
	}
	public String getExamSubject() {
		return examSubject;
	}
	public void setExamSubject(String examSubject) {
		this.examSubject = examSubject;
	}
	public Examination(int examId, Date examStartDate, Date examEndDate, String examSubject) {
		super();
		this.examId = examId;
		this.examStartDate = examStartDate;
		this.examEndDate = examEndDate;
		this.examSubject = examSubject;
	}
	@Override
	public String toString() {
		return "Examination [examId=" + examId + ", examStartDate=" + examStartDate + ", examEndDate=" + examEndDate
				+ ", examSubject=" + examSubject + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((examEndDate == null) ? 0 : examEndDate.hashCode());
		result = prime * result + examId;
		result = prime * result + ((examStartDate == null) ? 0 : examStartDate.hashCode());
		result = prime * result + ((examSubject == null) ? 0 : examSubject.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Examination other = (Examination) obj;
		if (examEndDate == null) {
			if (other.examEndDate != null)
				return false;
		} else if (!examEndDate.equals(other.examEndDate))
			return false;
		if (examId != other.examId)
			return false;
		if (examStartDate == null) {
			if (other.examStartDate != null)
				return false;
		} else if (!examStartDate.equals(other.examStartDate))
			return false;
		if (examSubject == null) {
			if (other.examSubject != null)
				return false;
		} else if (!examSubject.equals(other.examSubject))
			return false;
		return true;
	}
	
	
	
}