package com.virtusa.collegeportal.model;

//import java.sql.Date;

public class Student extends Applicant {

	public Student() {
	}
private int studentId;

private int studentPercentage;
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", studentPercentage=" + studentPercentage + ", studentClass="
			+ studentClass + ", applicant=" + applicant + ", joinYear=" + joinYear + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = super.hashCode();
	result = prime * result + ((applicant == null) ? 0 : applicant.hashCode());
	result = prime * result + joinYear;
	result = prime * result + ((studentClass == null) ? 0 : studentClass.hashCode());
	result = prime * result + studentId;
	result = prime * result + studentPercentage;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (!super.equals(obj))
		return false;
	if (getClass() != obj.getClass())
		return false;
	Student other = (Student) obj;
	if (applicant == null) {
		if (other.applicant != null)
			return false;
	} else if (!applicant.equals(other.applicant))
		return false;
	if (joinYear != other.joinYear)
		return false;
	if (studentClass == null) {
		if (other.studentClass != null)
			return false;
	} else if (!studentClass.equals(other.studentClass))
		return false;
	if (studentId != other.studentId)
		return false;
	if (studentPercentage != other.studentPercentage)
		return false;
	return true;
}
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public int getStudentPercentage() {
	return studentPercentage;
}
public void setStudentPercentage(int studentPercentage) {
	this.studentPercentage = studentPercentage;
}
public ClassRoom getStudentClass() {
	return studentClass;
}
public void setStudentClass(ClassRoom studentClass) {
	this.studentClass = studentClass;
}
public Applicant getApplicant() {
	return applicant;
}
public void setApplicant(Applicant applicant) {
	this.applicant = applicant;
}
public int getJoinYear() {
	return joinYear;
}
public void setJoinYear(int joinYear) {
	this.joinYear = joinYear;
}
private ClassRoom studentClass;
private Applicant applicant;
private int joinYear;
}
