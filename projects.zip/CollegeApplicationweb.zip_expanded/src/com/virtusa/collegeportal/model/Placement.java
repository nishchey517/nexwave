package com.virtusa.collegeportal.model;

import java.sql.Date;

public class Placement {

	public Placement() {

	}
	private int placementId;
	private Date placementDate;
	private String placementVenue;
	public int getPlacementId() {
		return placementId;
	}
	public void setPlacementId(int placementId) {
		this.placementId = placementId;
	}
	public Placement(int placementId, Date placementDate, String placementVenue) {
		super();
		this.placementId = placementId;
		this.placementDate = placementDate;
		this.placementVenue = placementVenue;
	}
	public Date getPlacementDate() {
		return placementDate;
	}
	public void setPlacementDate(Date placementDate2) {
		this.placementDate = placementDate2;
	}
	public String getPlacementVenue() {
		return placementVenue;
	}
	public void setPlacementVenue(String placementVenue) {
		this.placementVenue = placementVenue;
	}
	@Override
	public String toString() {
		return "Placement [placementId=" + placementId + ", placementDate=" + placementDate + ", placementVenue="
				+ placementVenue + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((placementDate == null) ? 0 : placementDate.hashCode());
		result = prime * result + placementId;
		result = prime * result + ((placementVenue == null) ? 0 : placementVenue.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Placement other = (Placement) obj;
		if (placementDate == null) {
			if (other.placementDate != null)
				return false;
		} else if (!placementDate.equals(other.placementDate))
			return false;
		if (placementId != other.placementId)
			return false;
		if (placementVenue == null) {
			if (other.placementVenue != null)
				return false;
		} else if (!placementVenue.equals(other.placementVenue))
			return false;
		return true;
	}
	

}
