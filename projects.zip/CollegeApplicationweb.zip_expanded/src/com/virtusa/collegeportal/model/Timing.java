package com.virtusa.collegeportal.model;

public class Timing {

	public Timing() {

	}
	private int time_id; 
	private String time_desc;
	public int getTime_id() {
		return time_id;
	}
	public void setTime_id(int time_id) {
		this.time_id = time_id;
	}
	public String getTime_desc() {
		return time_desc;
	}
	public void setTime_desc(String time_desc) {
		this.time_desc = time_desc;
	}
	@Override
	public String toString() {
		return "Timing [time_id=" + time_id + ", time_desc=" + time_desc + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((time_desc == null) ? 0 : time_desc.hashCode());
		result = prime * result + time_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Timing other = (Timing) obj;
		if (time_desc == null) {
			if (other.time_desc != null)
				return false;
		} else if (!time_desc.equals(other.time_desc))
			return false;
		if (time_id != other.time_id)
			return false;
		return true;
	}
	
}
