package com.virtusa.collegeportal.model;

import java.sql.Date;

public class CourseOffered {

	public CourseOffered() {

	}
private int courseId;
private String courseName;
private Date courseStartDate;
private Date  courseEndDate;

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((courseEndDate == null) ? 0 : courseEndDate.hashCode());
	result = prime * result + courseId;
	result = prime * result + ((courseName == null) ? 0 : courseName.hashCode());
	result = prime * result + ((courseStartDate == null) ? 0 : courseStartDate.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	CourseOffered other = (CourseOffered) obj;
	if (courseEndDate == null) {
		if (other.courseEndDate != null)
			return false;
	} else if (!courseEndDate.equals(other.courseEndDate))
		return false;
	if (courseId != other.courseId)
		return false;
	if (courseName == null) {
		if (other.courseName != null)
			return false;
	} else if (!courseName.equals(other.courseName))
		return false;
	if (courseStartDate == null) {
		if (other.courseStartDate != null)
			return false;
	} else if (!courseStartDate.equals(other.courseStartDate))
		return false;
	return true;
}
@Override
public String toString() {
	return "CourseOffered [courseId=" + courseId + ", courseName=" + courseName + ", courseStartDate=" + courseStartDate
			+ ", courseEndDate=" + courseEndDate + "]";
}
public int getCourseId() {
	return courseId;
}
public void setCourseId(int courseId) {
	this.courseId = courseId;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public Date getCourseStartDate() {
	return courseStartDate;
}
public void setCourseStartDate(Date courseStartDate) {
	this.courseStartDate = courseStartDate;
}
public Date getCourseEndDate() {
	return courseEndDate;
}
public void setCourseEndDate(Date courseEndDate) {
	this.courseEndDate = courseEndDate;
}


}
