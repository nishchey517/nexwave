package com.virtusa.collegeportal.model;

public class Subject {

	public Subject() {

	}
	private int subject_id;
	private String subject_name;
	public int getSubject_id() {
		return subject_id;
	}
	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	@Override
	public String toString() {
		return "Subject [subject_id=" + subject_id + ", subject_name=" + subject_name + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + subject_id;
		result = prime * result + ((subject_name == null) ? 0 : subject_name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subject other = (Subject) obj;
		if (subject_id != other.subject_id)
			return false;
		if (subject_name == null) {
			if (other.subject_name != null)
				return false;
		} else if (!subject_name.equals(other.subject_name))
			return false;
		return true;
	}
	
	
}
