package com.virtusa.collegeportal.model;

public class LoginDetail {
	String userId;
	String password;
	String usertype;
	@Override
	public String toString() {
		return "LoginDetail [userId=" + userId + ", password=" + password + ", usertype=" + usertype + "]";
	}
	public LoginDetail(String userId, String password, String usertype) {
		super();
		this.userId = userId;
		this.password = password;
		this.usertype = usertype;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	
}
