package com.virtusa.collegeportal.model;

public class Results {

	public Results() {

	}
private int resultId;
private String subject ;
private String status;
private int marks;
public int getResultId() {
	return resultId;
}
public void setResultId(int resultId) {
	this.resultId = resultId;
}
public String getSubject() {
	return subject;
}
public Results(int resultId, String subject, String status, int marks) {
	super();
	this.resultId = resultId;
	this.subject = subject;
	this.status = status;
	this.marks = marks;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + marks;
	result = prime * result + resultId;
	result = prime * result + ((status == null) ? 0 : status.hashCode());
	result = prime * result + ((subject == null) ? 0 : subject.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Results other = (Results) obj;
	if (marks != other.marks)
		return false;
	if (resultId != other.resultId)
		return false;
	if (status == null) {
		if (other.status != null)
			return false;
	} else if (!status.equals(other.status))
		return false;
	if (subject == null) {
		if (other.subject != null)
			return false;
	} else if (!subject.equals(other.subject))
		return false;
	return true;
}
@Override
public String toString() {
	return "Result [resultId=" + resultId + ", subject=" + subject + ", status=" + status + ", marks=" + marks + "]";
}

}