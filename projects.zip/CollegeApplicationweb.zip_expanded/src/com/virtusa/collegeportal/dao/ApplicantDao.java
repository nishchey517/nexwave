package com.virtusa.collegeportal.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mysql.jdbc.Statement;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Applicant;
import com.virtusa.collegeportal.model.CourseOffered;
import com.virtusa.collegeportal.service.Iapplicant;
import com.virtusa.collegeportal.util.ConnectionUtil;

public class ApplicantDao implements Iapplicant {

	Logger logger = Logger.getLogger("ApplicantDAO");

	@Override
	public  int register(Applicant applicant) throws CollegePortalException {
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int applicantId=0;
		CourseOffered courseOffered=new CourseOffered();
		
		try {
		preparedStatement=connection.prepareStatement("insert into applicant(ap_name,ap_mail,ap_contact,ap_gender,ap_rank,course) values(?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
	
		preparedStatement.setString(1,applicant.getApplicantName());
		preparedStatement.setString(2,applicant.getApplicantEmail());

		preparedStatement.setLong(3,applicant.getApplicantContact());
		preparedStatement.setString(6, applicant.getApplicantCourse());
		preparedStatement.setString(4, applicant.getApplicationGender());
		preparedStatement.setInt(5,applicant.getApplicantRank());
		
		resultSet = preparedStatement.getGeneratedKeys();


		  preparedStatement.executeUpdate();
		  if (resultSet.next()){
			  
				applicantId = resultSet.getInt(1);
		     }
		} catch (SQLException e) {

		e.printStackTrace();
		}
		finally {

			// close pstmt,connection,result set also
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}

		return applicantId;
		

	
	}

	@Override
	public String viewStatus(Applicant applicant) throws CollegePortalException {


		String query = "select ap_status from Applicant"+
				" where a.ap_id =?";
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String status=null;
		try {
			System.out.println(connection);
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, applicant.getApplicantId());
			resultSet=preparedStatement.executeQuery();
			while( resultSet.next())
			{
				status = resultSet.getString("ap_status");
			}

		}
		
		 catch (SQLException e) {

				logger.error("sql error", e);
				throw new CollegePortalException(e.getMessage());
			} catch (Exception e) {

				logger.error("internal error", e);
				throw new CollegePortalException(e.getMessage());
			}
		finally {

			
			try {

				if (resultSet != null) {

					resultSet.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				logger.error("sql error", e);

				throw new CollegePortalException(" error while closing a resource contact to admin");

			} catch (Exception e) {


				logger.error("internal error", e);
				throw new CollegePortalException("  contact to admin");

			}

		}
		return status;
	}
	
	
	
		
	

}
