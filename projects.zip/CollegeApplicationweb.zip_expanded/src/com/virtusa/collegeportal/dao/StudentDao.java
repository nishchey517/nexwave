package com.virtusa.collegeportal.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;


import com.virtusa.collegeportal.exception.CollegePortalException;
//import com.virtusa.collegeportal.model.Applicant;
import com.virtusa.collegeportal.model.Student;
import com.virtusa.collegeportal.model.Examination;
import com.virtusa.collegeportal.model.Placement;
import com.virtusa.collegeportal.model.Results;
import com.virtusa.collegeportal.service.Istudent;
import com.virtusa.collegeportal.util.ConnectionUtil;

public class StudentDao implements Istudent{
	Logger logger = Logger.getLogger("studentDao");

	@Override
	public List<Placement> viewPlacements() throws CollegePortalException {
		Connection connection=ConnectionUtil.getConnection();
		List<Placement> list=new ArrayList<>();
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		String query = "select * from placement";
		try{
			
			preparedStatement = connection.prepareStatement(query);			
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
			
				int placementId=resultSet.getInt("p_id");
				Date placementDate=resultSet.getDate("p_date");
				String placementVenue=resultSet.getString("p_companyname");
				Placement placement=new Placement();
				placement.setPlacementId(placementId);
				placement.setPlacementDate(placementDate);
				placement.setPlacementVenue(placementVenue);
				list.add(placement);
			
			
			}
		}
		
		
		catch (SQLException e) {

			logger.error("sql error", e);
			throw new CollegePortalException(e.getMessage());
		} catch (Exception e) {

			logger.error("internal error", e);
			throw new CollegePortalException(e.getMessage());
		}

		finally {

			
			try {

				if (resultSet != null) {

					resultSet.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				logger.error("sql error", e);

				throw new CollegePortalException(" error while closing a resource contact to admin");

			} 
		}


		return list;
	}


	@Override
	public List<Results> viewResult(int i) throws CollegePortalException {
		Connection connection=ConnectionUtil.getConnection();
		List<Results> list=new ArrayList<Results>();
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		String query = "select r_ex_id,r_score,r_status,ex_subject from result r join student s on r.r_s_id=s.s_id join examination e on e.ex_id=r.r_ex_id where s.s_id=?";
		try{
			
			preparedStatement = connection.prepareStatement(query);	
			preparedStatement.setInt(1, i);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
			
				int examId=resultSet.getInt("r_ex_id");
				int score=resultSet.getInt("r_score");
				String status=resultSet.getString("r_status");
				String subject=resultSet.getString("ex_subject");
				
				System.out.println(subject);
				Results results=new Results(examId,subject,status,score);
				list.add(results);
			
			
			}
		}
		
		
		catch (SQLException e) {

			logger.error("sql error", e);
			throw new CollegePortalException(e.getMessage());
		} catch (Exception e) {

			logger.error("internal error", e);
			throw new CollegePortalException(e.getMessage());
		}

		finally {

			
			try {

				if (resultSet != null) {

					resultSet.close();
				}

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				logger.error("sql error", e);

				throw new CollegePortalException(" error while closing a resource contact to admin");

			} 
		}
System.out.println(list.toString());

		return list;
	}
	@Override
	public int insertStudent(Student student) throws CollegePortalException {

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		
		try {
		preparedStatement=connection.prepareStatement("insert into student values(?,?,?,?)");
		preparedStatement.setInt(1,student.getStudentId());

		preparedStatement.setInt(2,student.getStudentPercentage());
		preparedStatement.setInt(3,student.getStudentClass().getClassId());
		preparedStatement.setInt(4,student.getApplicant().getApplicantId());
		return preparedStatement.executeUpdate();
		 } catch (SQLException e) {

		e.printStackTrace();
		}
		finally {

			
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}

		return 0;
		

	}

	@Override
	public int deleteStudent(Student student) throws CollegePortalException {
		
		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		
		try {
		preparedStatement=connection.prepareStatement("delete from student where st_id=?");
		preparedStatement.setInt(1,student.getStudentId());
		            return preparedStatement.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
			}
			finally {

				
				try {
					if (preparedStatement != null) {
						preparedStatement.close();
					}

					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {

					throw new CollegePortalException(" error while closing a resource contact to admin");

				}

			}
		return 0;
		


	}

	@Override
	public int updateStudent(Student student) throws CollegePortalException {

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;

		
		try {
		preparedStatement=connection.prepareStatement("update student set st_id=?,st_percent=?,st_applicant=?,st_classroom=?;");
		preparedStatement.setInt(1,student.getStudentId());

		preparedStatement.setInt(2,student.getStudentPercentage());
		preparedStatement.setInt(3,student.getStudentClass().getClassId());
		preparedStatement.setInt(4,student.getApplicant().getApplicantId());
		preparedStatement1=connection.prepareStatement("update applicant set ap_name=?,ap_contact=?,ap_email=?;");
		preparedStatement1.setString(1,student.getApplicant().getApplicantName());
		preparedStatement1.setFloat(2,student.getApplicant().getApplicantContact());
		preparedStatement1.setString(3,student.getApplicant().getApplicantEmail());
		 
		
		      int x=      preparedStatement.executeUpdate();
		      int y=      preparedStatement1.executeUpdate();
		
		     if(x>0&&y>0)
		   		 {
		   			 return 1;
		   		 }
		   		
		} catch (SQLException e) {

		e.printStackTrace();
		}
		finally {

			// close pstmt,connection,result set also
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}

		return 0;	

	}


public List<Examination> viewExamination() throws CollegePortalException {
Connection connection=ConnectionUtil.getConnection();
List<Examination> list=new ArrayList<>();
ResultSet resultSet = null;
PreparedStatement preparedStatement = null;
String query = "select * from Examination";
try{

preparedStatement = connection.prepareStatement(query);	
resultSet = preparedStatement.executeQuery();
while (resultSet.next()) {

int examId = resultSet.getInt("ex_id");
String examSubject = resultSet.getString("ex_subject");
Date examStartDate=resultSet.getDate("examStartDate");
Date examEndDate=resultSet.getDate("examEndDate");

Examination examination = new Examination();

examination.setExamId(examId);
examination.setExamSubject(examSubject);
examination.setExamStartDate(examStartDate) ;
   examination.setExamEndDate(examEndDate);
                 list.add(examination);


}
}


catch (SQLException e) {

logger.error("sql error", e);
throw new CollegePortalException(e.getMessage());
} catch (Exception e) {

logger.error("internal error", e);
throw new CollegePortalException(e.getMessage());
}

finally {


try {

if (resultSet != null) {

resultSet.close();
}

if (preparedStatement != null) {
preparedStatement.close();
}

if (connection != null) {
connection.close();
}
} catch (SQLException e) {

logger.error("sql error", e);

throw new CollegePortalException(" error while closing a resource contact to admin");

} 
}


return list;
}
}