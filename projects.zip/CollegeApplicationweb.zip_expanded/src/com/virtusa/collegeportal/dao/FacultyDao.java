package com.virtusa.collegeportal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.virtusa.collegeportal.exception.CollegePortalException;
//import com.virtusa.collegeportal.model.Applicant;
//import com.virtusa.collegeportal.model.ClassRoom;
import com.virtusa.collegeportal.model.Faculty;
//import com.virtusa.collegeportal.model.LoginDetail;
import com.virtusa.collegeportal.service.Ifaculty;
import com.virtusa.collegeportal.util.ConnectionUtil;

public class FacultyDao implements Ifaculty{

	@Override
	public int insertFaculty(Faculty faculty) throws CollegePortalException {
			Connection connection = ConnectionUtil.getConnection();
			PreparedStatement preparedStatement = null;

			
			try {
			preparedStatement=connection.prepareStatement("insert into applicant values(?,?,?,?,?)");
			preparedStatement.setInt(1,faculty.getFacultyId());
			preparedStatement.setString(2,faculty.getFacultyName());
			preparedStatement.setString(3,faculty.getFacultyEmail());
			preparedStatement.setFloat(4,faculty.getFacultyContact());
			preparedStatement.setInt(5,faculty.getClassroom().getClassId());
			            return preparedStatement.executeUpdate();
			} catch (SQLException e) {

			e.printStackTrace();
			}
			finally {

				
				try {
					if (preparedStatement != null) {
						preparedStatement.close();
					}

					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {

					throw new CollegePortalException(" error while closing a resource contact to admin");

				}

			}

			return 0;
			
	}

	@Override
	public int deleteFaculty(Faculty faculty) throws CollegePortalException {

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		
		try {
		preparedStatement=connection.prepareStatement("delete from faculty where fa_id=?");
		preparedStatement.setInt(1,faculty.getFacultyId());
		            return preparedStatement.executeUpdate();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		finally {

			
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}

		return 0;
	}

	@Override
	public int updateFaculty(Faculty faculty) throws CollegePortalException {

		Connection connection = ConnectionUtil.getConnection();
		PreparedStatement preparedStatement = null;

		try {
		preparedStatement=connection.prepareStatement("update faculty set fa_id=?, fa-name=?, fa_contact=?,fa_email=?,fa_cl_fk=? where fa_id=?");
		preparedStatement.setInt(1,faculty.getFacultyId());
		preparedStatement.setString(2,faculty.getFacultyName());
		preparedStatement.setString(3,faculty.getFacultyEmail());
		preparedStatement.setFloat(4,faculty.getFacultyContact());
		preparedStatement.setInt(5,faculty.getClassroom().getClassId());
		preparedStatement.setInt(6,faculty.getFacultyId());
		            return preparedStatement.executeUpdate();
		} catch (SQLException e) {

		e.printStackTrace();
		}
		finally {

			
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				throw new CollegePortalException(" error while closing a resource contact to admin");

			}

		}

		return 0;
	}

}
