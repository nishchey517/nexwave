package com.virtusa.collegeportal.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.service.Ialumini;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.util.AluminiView;
import com.virtusa.collegeportal.util.ConnectionUtil;
public class AluminiDao implements Ialumini {
	
	Logger logger = Logger.getLogger("AluminiDAO");
	
	@Override
	public List<AluminiView> checkSearch() throws CollegePortalException {

		String query = "select a.al_name,a.al_contact from Alumini a join Student s on a.al_s_id=s.s_id join applicant  ap on s.s_ap_id=ap.ap_id";
						

				List<AluminiView> list=new ArrayList<>();
				ResultSet resultSet = null;
				Connection connection = ConnectionUtil.getConnection();
				PreparedStatement preparedStatement = null;
				try {
					System.out.println(connection);
					preparedStatement = connection.prepareStatement(query);

					
					
					resultSet = preparedStatement.executeQuery();
					while (resultSet.next()) {

						String alumniName = resultSet.getString("al_name");
					    long studentContact=resultSet.getLong("al_contact");
						
						AluminiView alumini = new AluminiView(alumniName,studentContact);
						
						 list.add(alumini);
					}

				} catch (SQLException e) {

					logger.error("sql error", e);
					throw new CollegePortalException(e.getMessage());
				} catch (Exception e) {

					logger.error("internal error", e);
					throw new CollegePortalException(e.getMessage());
				}

				finally {

					// close pstmt,connection,result set also
					try {

						if (resultSet != null) {

							resultSet.close();
						}

						if (preparedStatement != null) {
							preparedStatement.close();
						}

						if (connection != null) {
							connection.close();
						}
					} catch (SQLException e) {

						logger.error("sql error", e);
						throw new CollegePortalException(" error while closing a resource contact to admin");

					} catch (Exception e) {
						

						logger.error("internal error", e);
						throw new CollegePortalException("  contact to admin");

					}

				}

				
				
				return list;
		
	}
	

}
