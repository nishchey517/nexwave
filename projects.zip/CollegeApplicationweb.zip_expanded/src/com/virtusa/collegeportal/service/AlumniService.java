package com.virtusa.collegeportal.service;


import java.util.List;

import com.virtusa.collegeportal.dao.AluminiDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.util.AluminiView;

public class AlumniService{

	public AlumniService() {
		// TODO Auto-generated constructor stub
	}

private AluminiDao aluminiDao=new AluminiDao();

public List<AluminiView> checkSearch() throws CollegePortalException {
	// TODO Auto-generated method stub
	
	return aluminiDao.checkSearch();
	
}



	
	

}
