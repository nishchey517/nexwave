package com.virtusa.collegeportal.service;

import java.util.List;

import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Placement;
import com.virtusa.collegeportal.model.Results;
import com.virtusa.collegeportal.model.Student;

public interface Istudent {
	//public int doLoginCheck(LoginDetail loginDetail);
	//public List<Assignment> checkAssignment(Student student);
	//public List<Result> checkResults(int studentId);
	public int insertStudent(Student student) throws CollegePortalException;
	public int deleteStudent(Student student) throws CollegePortalException;
	public int updateStudent(Student student) throws CollegePortalException;
	List<Placement> viewPlacements() throws CollegePortalException;
	
	List<Results> viewResult(int i) throws CollegePortalException;

}
