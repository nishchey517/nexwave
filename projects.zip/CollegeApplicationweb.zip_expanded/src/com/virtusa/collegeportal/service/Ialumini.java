package com.virtusa.collegeportal.service;

import java.util.List;

import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.util.AluminiView;

public interface Ialumini {
	//public int doLoginCheck(LoginDetail loginDetail) throws CollegePortalException;
	//public List<NewsAndEvents> checkNewsAndEvents() throws CollegePortalException;
//	public List<AluminiView> checkSearch(String s) throws CollegePortalException;

	List<AluminiView> checkSearch() throws CollegePortalException;


}