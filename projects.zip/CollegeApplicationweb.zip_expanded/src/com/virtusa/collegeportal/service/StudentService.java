package com.virtusa.collegeportal.service;

import java.util.List;

import com.virtusa.collegeportal.dao.StudentDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Placement;
import com.virtusa.collegeportal.model.Results;
import com.virtusa.collegeportal.model.Student;

public class StudentService implements Istudent{
	StudentDao studentDao=new StudentDao();

	public StudentService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Placement> viewPlacements() throws CollegePortalException {
		// TODO Auto-generated method stub
		return studentDao.viewPlacements();
	}

	@Override
	public int insertStudent(Student student) throws CollegePortalException {
		// TODO Auto-generated method stub
		return studentDao.insertStudent(student);
	}

	@Override
	public int deleteStudent(Student student) throws CollegePortalException {
		// TODO Auto-generated method stub
		return studentDao.deleteStudent(student);
	}

	@Override
	public int updateStudent(Student student) throws CollegePortalException {
		// TODO Auto-generated method stub
		return studentDao.updateStudent(student);
	}

	@Override
	public List<Results> viewResult(int i) throws CollegePortalException {
		// TODO Auto-generated method stub
		return studentDao.viewResult(i);
	}

}
