package com.virtusa.collegeportal.service;

import com.virtusa.collegeportal.model.NewsAndEvents;
import com.virtusa.collegeportal.model.Placement;

public interface Iadmin {
	public int insertnewsAndEvents(NewsAndEvents newsAndEvents);
	public int insertPlacement(Placement placement);
	//public int insertClassSchedule(ClassSchedule classSchedule);
	public int deleteNewsAndEvents(int id);
	public int deletePlacement(int id);
	

}
