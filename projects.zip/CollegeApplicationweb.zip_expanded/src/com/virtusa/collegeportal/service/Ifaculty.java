package com.virtusa.collegeportal.service;

import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Faculty;

public interface Ifaculty {
	
	//public int doLoginCheck(LoginDetail loginDetail);
	//public List<StudentPlacement> checkPlacements(Faculty faculty);
	//public List<ClassSchedule> checkSchedule(Faculty faculty);
	//public List<Assignment> checkAssignment(Faculty faculty);
	//public List<ClassExam> checkExam(Faculty faculty);
	//public List<Result> checkResult(Faculty faculty);
	//public List<NewsAndEvents> checkNewsAndEvents();
	public int insertFaculty(Faculty faculty) throws CollegePortalException;
	public int deleteFaculty(Faculty faculty) throws CollegePortalException;
	public int updateFaculty(Faculty faculty) throws CollegePortalException;
	

}
