package com.virtusa.collegeportal.service;

import com.virtusa.collegeportal.dao.ApplicantDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Applicant;


public class ApplicantService implements Iapplicant{

	public ApplicantService() {
		// TODO Auto-generated constructor stub
	}
	
	private ApplicantDao applicantDao=new ApplicantDao();

	@Override
	public String viewStatus(Applicant applicant) throws CollegePortalException {
		// TODO Auto-generated method stub
		return applicantDao.viewStatus(applicant);
	}

	@Override
	public int register(Applicant applicant) throws CollegePortalException {
		// TODO Auto-generated method stub
		return applicantDao.register(applicant);
	}
	
	
}
