package com.virtusa.collegeportal.service;

import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Applicant;

public interface Iapplicant {
	//public int register(Applicant applicant) throws CollegePortalException;
	//public int doLoginCheck(LoginDetail loginDetail) throws CollegePortalException;
	public String viewStatus(Applicant applicant) throws CollegePortalException;
	//public int insertApplicant(Applicant applicant) throws CollegePortalException;
	int register(Applicant applicant) throws CollegePortalException;

}
