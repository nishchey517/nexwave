package com.virtusa.collegeportal.service;

import com.virtusa.collegeportal.dao.FacultyDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Faculty;

public class FacultyService implements Ifaculty{
	public FacultyDao dao = new FacultyDao();

	@Override
	public int insertFaculty(Faculty faculty) throws CollegePortalException {
		// TODO Auto-generated method stub
		return dao.insertFaculty(faculty);
	}

	@Override
	public int deleteFaculty(Faculty faculty) throws CollegePortalException {
		// TODO Auto-generated method stub
		return dao.deleteFaculty(faculty);
	}

	@Override
	public int updateFaculty(Faculty faculty) throws CollegePortalException {
		// TODO Auto-generated method stub
		return dao.updateFaculty(faculty);
	}

}
