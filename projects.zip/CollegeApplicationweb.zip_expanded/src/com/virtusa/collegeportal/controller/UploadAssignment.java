package com.virtusa.collegeportal.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.model.Applicant;
import com.virtusa.collegeportal.model.Assignment;
import com.virtusa.collegeportal.service.ApplicantService;
import com.virtusa.collegeportal.util.AssignmentUtil;

/**
 * Servlet implementation class UploadAssignment
 */
@WebServlet("/UploadAssignment")
public class UploadAssignment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadAssignment() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Logger logger=Logger.getLogger("UploadAssignment");
		String assignmentName= request.getParameter("asname");
		String assignmentLink= request.getParameter("aslink");
		String assignmentDescription= request.getParameter("asdes");
		int facultyId= Integer.parseInt(request.getParameter("fid"));
		String subjectName= request.getParameter("suname");
		
		
		
	
Assignment assignment= new Assignment(assignmentLink,assignmentName,assignmentDescription,subjectName,facultyId);
System.out.println(assignment);


AssignmentUtil service=new AssignmentUtil();
logger.info("Service object is created");
RequestDispatcher dispatcher=null;



try{
	
	int genId=service.uploadAssignment(assignment);
	System.out.println(genId);
	if(genId!=0){
	 
	    dispatcher = request.getRequestDispatcher("/html/uploadassignment.html");
	}
	else{
		dispatcher = request.getRequestDispatcher("/html/studenthomepage.html"); 
	}
	
}
catch(Exception e){
	e.printStackTrace();
	dispatcher = request.getRequestDispatcher("/html/error.html");
	logger.error("err page",e);
}
dispatcher.forward(request, response);
	}

}