package com.virtusa.collegeportal.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.collegeportal.dao.ApplicantDao;
import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.model.Applicant;
import com.virtusa.collegeportal.service.ApplicantService;


/**
 * Servlet implementation class ApplicationController
 */
@WebServlet("/ApplicationController")
public class ApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplicationController() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Logger logger=Logger.getLogger("ApplicationController");
		String applicantName= request.getParameter("aname");
		String applicantEmail= request.getParameter("aemail");
		Long applicantContact= Long.parseLong(request.getParameter("acontact"));
		String applicationGender= request.getParameter("agender");
		int applicantRank= Integer.parseInt(request.getParameter("arank"));
		String applicantCourse= request.getParameter("acourse");
		
		
	
Applicant applicant=new Applicant( applicantName,applicantEmail,applicationGender,applicantContact, applicantRank,applicantCourse);

System.out.println("application" + applicant.toString() );
ApplicantService service=new ApplicantService();
logger.info("Service object is created");
RequestDispatcher dispatcher=null;


try{
	int genId=service.register(applicant);
	System.out.println(" ;;;;;;"+genId+" ;;;;;;");
	if(genId!=0){
		
		HttpSession session=request.getSession();

	    System.out.println(" ;;;;;;"+genId+" ;;;;;;");
	    
	    dispatcher = request.getRequestDispatcher("/html/applicanthomepage.html");
	}
	else{
		dispatcher = request.getRequestDispatcher("/html/applicationform.html"); 
	}
	
}
catch(Exception e){
	e.printStackTrace();
	dispatcher = request.getRequestDispatcher("/html/error.html");
	logger.error("err page",e);
}
dispatcher.forward(request, response);
	}

}