package com.virtusa.collegeportal.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.collegeportal.exception.CollegePortalException;

import com.virtusa.collegeportal.util.ClassScheduleUtil;
import com.virtusa.collegeportal.util.ClassScheduleView;
import com.virtusa.collegeportal.util.ConnectionUtil;
import com.virtusa.collegeportal.util.NewsAndEventsUtil;

/**
 * Servlet implementation class ViewNewsAndEvents
 */
@WebServlet("/ViewClassSchedule")
public class ViewClassSchedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewClassSchedule() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection d=null;
		
		System.out.println(d);

		response.setContentType("text/html");

		
		ClassScheduleUtil service = new ClassScheduleUtil();
		List<ClassScheduleView> list =new ArrayList<ClassScheduleView>();

		try {
			list = service.checkClassSchedule();
		} catch (CollegePortalException e) {

			e.printStackTrace();
		}

		if (list.isEmpty()) {

			System.out.println("List is empty");

		} else {
			System.out.println("List is not empty");
			request.setAttribute("classSchedule", list);
			request.getRequestDispatcher("/jsp/classSchedule.jsp").forward(request, response);

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
