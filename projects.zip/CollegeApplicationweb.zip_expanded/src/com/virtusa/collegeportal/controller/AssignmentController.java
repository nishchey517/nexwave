package com.virtusa.collegeportal.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.collegeportal.exception.CollegePortalException;
import com.virtusa.collegeportal.util.AssignmentUtil;
import com.virtusa.collegeportal.util.AssignmentView;


/**
 * Servlet implementation class AssignmentController
 */
@WebServlet("/AssignmentController")
public class AssignmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignmentController() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
Connection d=null;
		
		System.out.println(d);

		response.setContentType("text/html");

		
		AssignmentUtil service = new AssignmentUtil();
		List<AssignmentView> list =new ArrayList<AssignmentView>();


		try {
			list = service.downloadAssignment();
		} catch (CollegePortalException e) {

			e.printStackTrace();
		}

		if (list.isEmpty()) {

			System.out.println("List is empty");

		} else {
			System.out.println("List is not empty");
			request.setAttribute("assignment", list);
			request.getRequestDispatcher("/jsp/downloadAssignment.jsp").forward(request, response);

		}

	}
	
	
	
	
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
