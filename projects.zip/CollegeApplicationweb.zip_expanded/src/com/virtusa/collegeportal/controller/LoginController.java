package com.virtusa.collegeportal.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

//import com.virtusa.collegeportal.model.Alumini;
import com.virtusa.collegeportal.model.LoginDetail;
//import com.virtusa.collegeportal.service.AlumniService;
import com.virtusa.collegeportal.util.Login;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();

    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		Logger logger=Logger.getLogger("loginController");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<h>Welcome to Servlet</h>");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String usertype = request.getParameter("usertype");
		int flag=0;
		LoginDetail loginDetail = new LoginDetail(username,password,usertype);

		Login service = new Login();
		
		try {
		flag = service.doLoginCheck(loginDetail);

		if(flag==0){
		logger.info("Not Successfully login");
		RequestDispatcher dispatcher = request.getRequestDispatcher("/html/index.html");
		dispatcher.forward(request, response);
		}
		else{
			if(usertype.equals("student")){
			logger.info("Successfully login plz display Home page");
			HttpSession session=request.getSession();
		    session.setAttribute("user", loginDetail);
		    System.out.println("login");
		    RequestDispatcher dispatcher = request.getRequestDispatcher("/html/studenthomepage.html"); 
		    dispatcher.forward(request, response);}
			else if(usertype.equals("faculty")){
				logger.info("Successfully login plz display Home page");
				HttpSession session=request.getSession();
			    session.setAttribute("user", loginDetail);
			    System.out.println("login");
			    RequestDispatcher dispatcher = request.getRequestDispatcher("/html/staffhomepage.html"); 
			    dispatcher.forward(request, response);}
			else if(usertype.equals("applicant")){
				logger.info("Successfully login plz display Home page");
				HttpSession session=request.getSession();
			    session.setAttribute("user", loginDetail);
			    System.out.println("login");
			    RequestDispatcher dispatcher = request.getRequestDispatcher("/html/applicanthomepage.html"); 
			    dispatcher.forward(request, response);}
			else{
				logger.info("Successfully login plz display Home page");
				HttpSession session=request.getSession();
			    session.setAttribute("user", loginDetail);
			    System.out.println("login");
			    RequestDispatcher dispatcher = request.getRequestDispatcher("/html/alumnihomepage.html"); 
			    dispatcher.forward(request, response);}
		}
		} catch (Exception e) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/html/error.html"); 
			dispatcher.forward(request, response);
			logger.error("internal error while login",e);
		     
			

		}
		 
		}

		}
