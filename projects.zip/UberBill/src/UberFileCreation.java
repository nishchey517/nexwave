import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

public class UberFileCreation {
	private long serialNumber;
	private String userId;
	private Date date;
	private String source;
	private String destination;
	private float fare;
	int i = 0;
	private float totalFare;
	static HashMap<String, Float> h = new HashMap<String, Float>();

	public UberFileCreation(long serialNumber, String userId, Date date, String source, String destination, float fare,
			HashMap<String, Float> h) {
		// TODO Auto-generated constructor stub
		this.serialNumber = serialNumber;
		this.userId = userId;
		this.date = date;
		this.source = source;
		this.destination = destination;
		this.h = h;
		this.fare = fare;
	}

	public long getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(long serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public HashMap<String, Float> creatingFiles() throws IOException {
		File file = new File(userId + ".txt");

		if (file.createNewFile()) {
			// fileNames[i] = file;
			// i++;
			h.put(userId, fare);
			FileWriter fw = new FileWriter(file);
			fw.write("S.No\t\t\tDate\t\t\tsource\t\t\tdestination\t\t\tamount\n");
			fw.write("=========================================================================================\n");
			fw.write(serialNumber + "\t\t\t" + date + "\t\t\t" + source + "\t\t\t" + destination + "\t\t\t" + fare);
			fw.close();
			System.out.println("Created");
			System.out.println(h);
		} else {
			totalFare = h.get(userId) + fare;
			h.put(userId, totalFare);
			System.out.println(h);
			BufferedWriter out = new BufferedWriter(new FileWriter(file, true));
			out.write("\n" + serialNumber + "\t\t\t" + date + "\t\t\t" + source + "\t\t\t" + destination + "\t\t\t"
					+ fare + "\n");
			out.close();
		}

		return h;
	}
}
