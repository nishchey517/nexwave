import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Scanner;

public class UberMain {
	public static void main(String[] args) throws IOException, ParseException {
		long serialNumber;
		String userId;
		Date date;
		String source;
		String destination;
		float fare;
		
		HashMap<String, Float> h=new HashMap<String,Float>();
		UberFileCreation uber = null;
		FileReader file = new FileReader("UberData");
		SimpleDateFormat f1 = new SimpleDateFormat("dd/mm/yyyy HH:mm:ss");
		Scanner s = new Scanner(file);
		while (s.hasNextLine()) {
			String line = s.nextLine();
			String[] dataLines = line.split(",");
			serialNumber = Long.parseLong(dataLines[0]);
			userId = dataLines[1];
			date = f1.parse(dataLines[2]);
			source = dataLines[3];
			destination = dataLines[4];
			fare = Float.parseFloat(dataLines[5]);
			uber = new UberFileCreation(serialNumber, userId, date, source, destination, fare,h);
			h=uber.creatingFiles();
		}
		Set<String> keyset=h.keySet();
		Iterator<String> i=keyset.iterator();
		
		System.out.println(keyset);
		while(i.hasNext()) {
			String key = i.next();	
			System.out.println(key+".txt");
			File file1 = new File(key + ".txt");

			BufferedWriter out = new BufferedWriter(new FileWriter(file1, true));
			out.write("\n User Id \t\t\t\t\t TotalCost\n");
			out.write("======================================================================\n");
			out.write(key+"\t\t\t\t\t"+h.get(key));
			out.write("\n\n\nOffers\n");
			out.write("==================\n");
			String msg;
			if(h.get(key)>5000) {
				msg="50%off for next Five ride";
				out.write(msg);
			}
			else {
				out.write("No Offer For This User");
			}
			out.close();
			
		}
		
	
	}
}
