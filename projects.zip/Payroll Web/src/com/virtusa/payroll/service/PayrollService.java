package com.virtusa.payroll.service;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.BenefitDetail;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Investment;
import com.virtusa.payroll.model.LoginDetail;
import com.virtusa.payroll.model.PayrollData;
import com.virtusa.payroll.model.Reimbursement;
import com.virtusa.payroll.model.Salary;
import com.virtusa.payroll.model.Security;

public class PayrollService implements IPayroll{
	private PayrollDao dao=new PayrollDao();
	@Override
	public int doLoginCheck(LoginDetail loginDetail) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String retrieveResult(int emp_id) throws PayrollException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doFirstUserCheck(int employeeId) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int checkEmployeeId(int emp_id) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int createSecurityCheck(Security securityDetail) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doSecurityCheck(Security securityDetail) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updatePassword(LoginDetail loginDetail) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee viewDetails(int employeeId) throws PayrollException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateDetails(Employee employee) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String viewPayslip(PayrollData payrollData) throws PayrollException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Salary viewCtc(int employeeId) throws PayrollException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doInvestmentDeclaration(int emp_id, Investment investment) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int changeBenefitDetail(BenefitDetail benefits) throws PayrollException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BenefitDetail getBenefitDetails(int employeeId) throws PayrollException {
		// TODO Auto-generated method stub
		return null;
	}

	public int claimReimbursement(int emp_id, Reimbursement reimbursement) throws PayrollException {
		// TODO Auto-generated method stub
		System.out.println("Entered service");
		return dao.claimReimbursement(emp_id, reimbursement);
	}

}
