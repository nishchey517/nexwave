package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.LoginDetail;

/**
 * Servlet implementation class SecurityUpdateController
 */
@WebServlet("/SecurityUpdateController")
public class SecurityUpdateController extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecurityUpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		RequestDispatcher dispatcher;
		PayrollDao dao=new PayrollDao();
		int flag;
		LoginDetail loginDetail =new LoginDetail();
		String password=request.getParameter("confirmPassword");
		HttpSession session=request.getSession();
		String username=session.getAttribute("user").toString();
		System.out.println("password is suc is"+password);
		System.out.println("username is suc is"+username);
		
		loginDetail.setUsername(username);
		loginDetail.setPassword(password);
		try {
			flag=dao.updatePassword(loginDetail);
			if(flag==1)
			{
				dispatcher=request.getRequestDispatcher("/jsp/welcome.jsp");
				dispatcher.forward(request, response);
			}
			else
			{
				dispatcher=request.getRequestDispatcher("/jsp/securityquestion.jsp");
				dispatcher.forward(request, response);
			}
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
