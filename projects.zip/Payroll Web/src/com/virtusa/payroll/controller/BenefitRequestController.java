package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.BenefitDetail;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.service.IMessages;


@WebServlet("/BenefitRequestController")
public class BenefitRequestController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BenefitRequestController() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		int emp_id=Integer.parseInt(session.getAttribute("user").toString());
		PrintWriter out=response.getWriter();
		PayrollDao dao=new PayrollDao();
		RequestDispatcher dispatcher=null;
		System.out.println("1");
		try {
			BenefitDetail benefitDetail=dao.getBenefitDetails(emp_id);
			System.out.println("1");
			request.setAttribute("lta", benefitDetail.getBen_lta());
			request.setAttribute("phone", benefitDetail.getBen_phone());
			request.setAttribute("childfee", benefitDetail.getBen_childfee());
			request.setAttribute("food", benefitDetail.getBen_food());
			dispatcher=request.getRequestDispatcher("/jsp/Benefits.jsp");
			System.out.println("1zz");
			dispatcher.forward(request, response);
		
		
		} catch (PayrollException e) {
			out.println(IMessages.contactAdmin);
		}
		
	}

	
	

}
