package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.PayrollDao;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.PayrollData;
import com.virtusa.payroll.service.IMessages;


@WebServlet("/ViewPayslipController")
public class ViewPayslipController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ViewPayslipController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String date=request.getParameter("date");
		PrintWriter out=response.getWriter();
		String[] month_year=date.split("-");
		out.println(month_year[0]);
		HttpSession session=request.getSession();
		int id=Integer.parseInt(session.getAttribute("user").toString());
		Employee employee=new Employee();
		employee.setEmp_id(id);
		PayrollData payrollData=new PayrollData();
		payrollData.setEmployee(employee);
		payrollData.setPay_month(month_year[1]);
		payrollData.setPay_year(Integer.parseInt(month_year[0]));
		System.out.println(payrollData.getEmployee().getEmp_id()+" "+payrollData.getPay_month()+" "+payrollData.getPay_year());
		PayrollDao dao=new PayrollDao();
		RequestDispatcher dispatcher=null;
		try {
			String path=dao.viewPayslip(payrollData);
			request.setAttribute("path", path);
			dispatcher=request.getRequestDispatcher("/jsp/viewpayroll.jsp");
			dispatcher.forward(request, response);
			
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			out.println(IMessages.contactAdmin);
		}
	}

}
