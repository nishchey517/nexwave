package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.virtusa.payroll.exception.PayrollException;
import com.virtusa.payroll.model.Employee;
import com.virtusa.payroll.model.Reimbursement;
import com.virtusa.payroll.service.IMessages;
import com.virtusa.payroll.service.PayrollService;

/**
 * Servlet implementation class ReimbursementController
 */
@WebServlet("/ReimbursementController")
public class ReimbursementController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ReimbursementController() {
		super();

	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PayrollService service = new PayrollService();
		PrintWriter out = response.getWriter();
	
		HttpSession session = request.getSession();
		int emp_id = Integer.parseInt(session.getAttribute("user").toString());
		Employee employee = new Employee();
		employee.setEmp_id(emp_id);
		String Re_type = request.getParameter("type");
		String amount = request.getParameter("Amount");
		float Re_amount = Float.parseFloat(amount);
		String Re_path = request.getParameter("proof");
		Reimbursement reimbursement = new Reimbursement();
		reimbursement.setEmployee(employee);
		reimbursement.setRe_type(Re_type);
		reimbursement.setRe_amount(Re_amount);
		reimbursement.setRe_path(Re_path);
		int flag=0;
		RequestDispatcher dispatcher = null;		
		try {
			flag = service.claimReimbursement(emp_id,reimbursement);
			if (flag!=0) {
				dispatcher = request.getRequestDispatcher("/html/Success.html");
				dispatcher.forward(request, response);
			}
		} catch (PayrollException e) {
			out.println(IMessages.contactAdmin);
		}

	}

}
