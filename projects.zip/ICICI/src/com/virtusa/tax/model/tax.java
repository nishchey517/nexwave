package com.virtusa.tax.model;

public class tax {

	float t;
	public static float taxCal(float salary)
	{
		if(salary<=250000)
		{
			return 0;
		}
		else if(salary>250000 && salary<=500000)
		{
			return ((salary-250000)*5)/100;
		}
		else if(salary>500000 && salary<=1000000)
		{
			return (((salary-500000)*20)/100)+12500;
			//return t;
		}
		else 
		{
			return 0;
		}
	}
	public tax() {
		
		
	}

}
