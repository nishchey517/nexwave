package com.virtusa.tax.app;

import com.virtusa.bank.model.Account;
import com.virtusa.tax.model.Address;
import com.virtusa.tax.model.Employee;
import com.virtusa.tax.model.tax;

public class taxMain {

	public static void main(String ags[])
	{
		String[] data={"1,John,25,250000,john@email.com,51 Ram Street,Venkat Nagar,Thoraipakkam,Chennai,600001",
					"2,Jon,26,500000,jon@email.com,51 famous Street,Venky Nagar,Thoraipakkam,Chennai,600001",
					"3,Johny,30,750000,johny@email.com,51 white Street,raju Nagar,Thoraipakkam,Chennai,600001",
					"4,Johnny,28,350000,johnny@email.com,51 black Street,Venk Nagar,Thoraipakkam,Chennai,600001",
					"5,Jonn,22,870000,jonn@email.com,51 eden Street,Venkat Nagar,Thoraipakkam,Chennai,600001",
					"6,Jonny,35,590000,jonny@email.com,51 Ram Street,Venkat Nagar,Thoraipakkam,Chennai,600001"
					};
	
		for(int i=0;i<data.length;i++)
		{
			String temp=data[i];
			String arr[]=temp.split(",");
			int id=Integer.parseInt(arr[0]);
			String name=arr[1];
			int age=Integer.parseInt(arr[2]);
			Float salary=Float.parseFloat(arr[3]);
			String email=arr[4];
			String addressLine1=arr[5];
			String addressLine2=arr[6];
			String locality=arr[7];
			String city=arr[8];
			int pincode=Integer.parseInt(arr[9]);
			Address address=new Address(addressLine1,addressLine2,locality,city,pincode);
			Employee employee=new Employee(id,name,email,age,salary,address);
			float t=tax.taxCal(salary);
			System.out.println(employee);
			System.out.println("Employee tax: "+i+" "+t);
		}
	}

}
