package com.virtusa.bank.model;

public class creditCard extends Account 
{

}
