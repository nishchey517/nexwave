package com.virtusa.bank.model;

public class Account {

	public Account() {

	}

	private float amount;
	private float transAmount;
	private char transType;
	private long accountNumber;
	private char accountType;

	@Override
	public String toString() {
		return "Account [amount=" + amount + ", accountNumber=" + accountNumber + "]";
	}

	public Account(float amount, float transAmount, char transType, long accountNumber, char accountType) {
		super();
		this.amount = amount;
		this.transAmount = transAmount;
		this.transType = transType;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
	}

	public char getAccountType() {
		return accountType;
	}

	public void setAccountType(char accountType) {
		this.accountType = accountType;
	}

	public Account(float amount, long accountNumber) {
		super();
		this.amount = amount;
		this.accountNumber = accountNumber;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public float getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(float transAmount) {
		this.transAmount = transAmount;
	}

	public char getTransType() {
		return transType;
	}

	public void setTransType(char transType) {
		this.transType = transType;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	private void deposit(float transAmount,char accountType) {
		if (transAmount > 100000 && (accountType=='n' || accountType=='N')) {
			//System.out.println("You cannot deposit that much amount in a single attempt");
			//System.exit(0);
			//System.out.println("Before Deposit your Amount is:" + amount);
			float bonus=(2*amount)/100;
			//System.out.println("You got bonus of:" + bonus);
			amount=amount+transAmount+bonus;
			//System.out.println("After Deposit your Amount is:" + amount);
		} 
		else 
		{
			//System.out.println("Before Deposit your Amount is:" + amount);
			amount = amount + transAmount;
			//System.out.println("After Deposit your Amount is:" + amount);
		}
	}

	private void withdraw(float transAmoun) {
		if (transAmoun > amount) {
			//System.out.println("You Cannot WithDraw Becoz You Are having Less Amount in your Account");
			//System.out.println("Have A Great Day!!");
		} else {
			//System.out.println("Before Transaction your Amount is:" + amount);
			amount = amount - transAmount;
			//System.out.println("After Transaction your Amount is:" + amount);
		}
	}

	public void transaction(float transamount, char transType) {
		if (transType == 'w' || transType == 'W') {
			withdraw(transamount);
		} else if (transType == 'd' || transType == 'D') {
			deposit(transamount,accountType);
		}
	}

}
