package com.virtusa.bank.app;

import java.util.ArrayList;

import com.virtusa.bank.model.Account;

public class BankMain {

	public static void main(String ags[]){
		String[] data={"100001,20000,d,1000001,n","100002,60000,d,2000,c","100003,50000,d,1000,c","100004,10000,d,1000,c"};
		ArrayList list=new ArrayList<>();
		Account ar[]=new Account[data.length];
		for(int i=0;i<data.length;i++)
		{
			String temp=data[i];
			String arr[]=temp.split(",");
			long accountNumber = Long.parseLong(arr[0]);
			float amount = Float.parseFloat(arr[1]);
			char transType=arr[2].charAt(0);
		    float transAmount = Float.parseFloat(arr[3]);
			char accountType=arr[4].charAt(0);
			
			
		Account account=new Account(amount,accountNumber);
		ar[i]=account;
		 // System.out.println("qssfsf");
		list.add(ar[i]);
		account.transaction(transAmount,transType);
		}
		for(int j=0;j<list.size();j++)
		{
			System.out.println(list.get(j));
		}
	}

}
   