package com.virtusa.payroll.model;

import java.time.LocalDate;

public class Employee 
{
	private int employeeID;
	private String employeePassword;
	private String employeeName;
	private String employeeGender;
	private String employeePan;
	private LocalDate employeeDoj;
	private LocalDate employeeDob;
	private Location location;
	private Designation designation;
	private Account account;
	private Salary salary;
	private Mbopayouts mbopayouts;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeID, String employeePassword, String employeeName, String employeeGender,
			String employeePan, LocalDate employeeDoj, LocalDate employeeDob, Location location,
			Designation designation, Account account, Salary salary, Mbopayouts mbopayouts) {
		super();
		this.employeeID = employeeID;
		this.employeePassword = employeePassword;
		this.employeeName = employeeName;
		this.employeeGender = employeeGender;
		this.employeePan = employeePan;
		this.employeeDoj = employeeDoj;
		this.employeeDob = employeeDob;
		this.location = location;
		this.designation = designation;
		this.account = account;
		this.salary = salary;
		this.mbopayouts = mbopayouts;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeePassword() {
		return employeePassword;
	}
	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeGender() {
		return employeeGender;
	}
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}
	public String getEmployeePan() {
		return employeePan;
	}
	public void setEmployeePan(String employeePan) {
		this.employeePan = employeePan;
	}
	public LocalDate getEmployeeDoj() {
		return employeeDoj;
	}
	public void setEmployeeDoj(LocalDate employeeDoj) {
		this.employeeDoj = employeeDoj;
	}
	public LocalDate getEmployeeDob() {
		return employeeDob;
	}
	public void setEmployeeDob(LocalDate employeeDob) {
		this.employeeDob = employeeDob;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	public Designation getDesignation() {
		return designation;
	}
	public void setDesignation(Designation designation) {
		this.designation = designation;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	public Mbopayouts getMbopayouts() {
		return mbopayouts;
	}
	public void setMbopayouts(Mbopayouts mbopayouts) {
		this.mbopayouts = mbopayouts;
	}
	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", employeePassword=" + employeePassword + ", employeeName="
				+ employeeName + ", employeeGender=" + employeeGender + ", employeePan=" + employeePan
				+ ", employeeDoj=" + employeeDoj + ", employeeDob=" + employeeDob + ", location=" + location
				+ ", designation=" + designation + ", account=" + account + ", salary=" + salary + ", mbopayouts="
				+ mbopayouts + "]";
	}
	
	
	
	
	
}
