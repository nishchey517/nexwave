package com.virtusa.payroll.model;

public class Mbopayouts 
{
	private float mboRating;
	private String mboBonus;
	
	public Mbopayouts() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mbopayouts(float mboRating, String mboBonus) {
		super();
		this.mboRating = mboRating;
		this.mboBonus = mboBonus;
	}
	public float getMboRating() {
		return mboRating;
	}
	public void setMboRating(float mboRating) {
		this.mboRating = mboRating;
	}
	public String getMboBonus() {
		return mboBonus;
	}
	public void setMboBonus(String mboBonus) {
		this.mboBonus = mboBonus;
	}
	@Override
	public String toString() {
		return "Mbopayouts [mboRating=" + mboRating + ", mboBonus=" + mboBonus + "]";
	}
	
	
	
	
}
