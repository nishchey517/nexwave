package com.virtusa.payroll.model;

public class Benefits
{
	private float benefitsFood;
	private float benefitsChildFee;
	private float benefitsPhoneReimbursement;
	private float benefitsTravelAllowances;  
	private Employee employee;
	
	public Benefits() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Benefits(float benefitsFood, float benefitsChildFee, float benefitsPhoneReimbursement,
			float benefitsTravelAllowances, Employee employee) {
		super();
		this.benefitsFood = benefitsFood;
		this.benefitsChildFee = benefitsChildFee;
		this.benefitsPhoneReimbursement = benefitsPhoneReimbursement;
		this.benefitsTravelAllowances = benefitsTravelAllowances;
		this.employee = employee;
	}
	public float getBenefitsFood() {
		return benefitsFood;
	}
	public void setBenefitsFood(float benefitsFood) {
		this.benefitsFood = benefitsFood;
	}
	public float getBenefitsChildFee() {
		return benefitsChildFee;
	}
	public void setBenefitsChildFee(float benefitsChildFee) {
		this.benefitsChildFee = benefitsChildFee;
	}
	public float getBenefitsPhoneReimbursement() {
		return benefitsPhoneReimbursement;
	}
	public void setBenefitsPhoneReimbursement(float benefitsPhoneReimbursement) {
		this.benefitsPhoneReimbursement = benefitsPhoneReimbursement;
	}
	public float getBenefitsTravelAllowances() {
		return benefitsTravelAllowances;
	}
	public void setBenefitsTravelAllowances(float benefitsTravelAllowances) {
		this.benefitsTravelAllowances = benefitsTravelAllowances;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Benefits [benefitsFood=" + benefitsFood + ", benefitsChildFee=" + benefitsChildFee
				+ ", benefitsPhoneReimbursement=" + benefitsPhoneReimbursement + ", benefitsTravelAllowances="
				+ benefitsTravelAllowances + ", employee=" + employee + "]";
	}
	
	
	
	
}
