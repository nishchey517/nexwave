package com.virtusa.payroll.model;

public class Investment 
{
	private String investmentLoan;
	private String investmentPpf;
	private String investmentEducationLoan;
	private String investmentInsurance;
	private Employee employee;
	
	public Investment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Investment(String investmentLoan, String investmentPpf, String investmentEducationLoan,
			String investmentInsurance, Employee employee) {
		super();
		this.investmentLoan = investmentLoan;
		this.investmentPpf = investmentPpf;
		this.investmentEducationLoan = investmentEducationLoan;
		this.investmentInsurance = investmentInsurance;
		this.employee = employee;
	}
	public String getInvestmentLoan() {
		return investmentLoan;
	}
	public void setInvestmentLoan(String investmentLoan) {
		this.investmentLoan = investmentLoan;
	}
	public String getInvestmentPpf() {
		return investmentPpf;
	}
	public void setInvestmentPpf(String investmentPpf) {
		this.investmentPpf = investmentPpf;
	}
	public String getInvestmentEducationLoan() {
		return investmentEducationLoan;
	}
	public void setInvestmentEducationLoan(String investmentEducationLoan) {
		this.investmentEducationLoan = investmentEducationLoan;
	}
	public String getInvestmentInsurance() {
		return investmentInsurance;
	}
	public void setInvestmentInsurance(String investmentInsurance) {
		this.investmentInsurance = investmentInsurance;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Investment [investmentLoan=" + investmentLoan + ", investmentPpf=" + investmentPpf
				+ ", investmentEducationLoan=" + investmentEducationLoan + ", investmentInsurance="
				+ investmentInsurance + ", employee=" + employee + "]";
	}
	
	
	
	
}
