package com.virtusa.payroll.model;

import java.time.LocalDate;

public class Payrolldata 
{
	private LocalDate payDate;
	private String payDetails;
	private Employee employee;
	
	public Payrolldata() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payrolldata(LocalDate payDate, String payDetails, Employee employee) {
		super();
		this.payDate = payDate;
		this.payDetails = payDetails;
		this.employee = employee;
	}
	public LocalDate getPayDate() {
		return payDate;
	}
	public void setPayDate(LocalDate payDate) {
		this.payDate = payDate;
	}
	public String getPayDetails() {
		return payDetails;
	}
	public void setPayDetails(String payDetails) {
		this.payDetails = payDetails;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	@Override
	public String toString() {
		return "Payrolldata [payDate=" + payDate + ", payDetails=" + payDetails + ", employee=" + employee + "]";
	}
	
	
	
	
}
