package com.virtusa.payroll.model;

public class Designation 
{
	private int designationID;
	private String designationName;
	
	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Designation(int designationID, String designationName) {
		super();
		this.designationID = designationID;
		this.designationName = designationName;
	}
	@Override
	public String toString() {
		return "Designation [designationID=" + designationID + ", designationName=" + designationName + "]";
	}
	public int getDesignationID() {
		return designationID;
	}
	public void setDesignationID(int designationID) {
		this.designationID = designationID;
	}
	public String getDesignationName() {
		return designationName;
	}
	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}
	
	
	
}
