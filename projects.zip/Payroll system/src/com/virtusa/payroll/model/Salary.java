package com.virtusa.payroll.model;

public class Salary
{
	private int salaryId;
	private int salaryPackage;
	private float salaryBasic;
	private float salaryHra;
	private float salaryBonus;
	private float salaryAllowance;
	
	public Salary() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Salary(int salaryId, int salaryPackage, float salaryBasic, float salaryHra, float salaryBonus,
			float salaryAllowance) {
		super();
		this.salaryId = salaryId;
		this.salaryPackage = salaryPackage;
		this.salaryBasic = salaryBasic;
		this.salaryHra = salaryHra;
		this.salaryBonus = salaryBonus;
		this.salaryAllowance = salaryAllowance;
	}
	public int getSalaryId() {
		return salaryId;
	}
	public void setSalaryId(int salaryId) {
		this.salaryId = salaryId;
	}
	public int getSalaryPackage() {
		return salaryPackage;
	}
	public void setSalaryPackage(int salaryPackage) {
		this.salaryPackage = salaryPackage;
	}
	public float getSalaryBasic() {
		return salaryBasic;
	}
	public void setSalaryBasic(float salaryBasic) {
		this.salaryBasic = salaryBasic;
	}
	public float getSalaryHra() {
		return salaryHra;
	}
	public void setSalaryHra(float salaryHra) {
		this.salaryHra = salaryHra;
	}
	public float getSalaryBonus() {
		return salaryBonus;
	}
	public void setSalaryBonus(float salaryBonus) {
		this.salaryBonus = salaryBonus;
	}
	public float getSalaryAllowance() {
		return salaryAllowance;
	}
	public void setSalaryAllowance(float salaryAllowance) {
		this.salaryAllowance = salaryAllowance;
	}
	@Override
	public String toString() {
		return "Salary [salaryId=" + salaryId + ", salaryPackage=" + salaryPackage + ", salaryBasic=" + salaryBasic
				+ ", salaryHra=" + salaryHra + ", salaryBonus=" + salaryBonus + ", salaryAllowance=" + salaryAllowance
				+ "]";
	}
	
	
	
	
}
