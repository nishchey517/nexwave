package com.virtusa.payroll.service;

import com.virtusa.payroll.model.LoginDetail;

public interface IPayroll 
{
	public int claimReimbursement(LoginDetail loginDetail);
	//public void updateProfile();
	//public int forgotPassowrd();
	//public int viewPayslip();
	//public int doInvestmentDeclaration();
	//public int viewCtc();
	//public int downloadPayslip();
	//public int doBenefitPlan();
	//public int doLogout();	
}
