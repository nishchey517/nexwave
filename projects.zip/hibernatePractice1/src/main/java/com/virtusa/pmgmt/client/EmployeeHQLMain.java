package com.virtusa.pmgmt.client;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.virtusa.pmgmt.model.Product;


public class EmployeeHQLMain 
{
	public static void main(String[] args)
	{
		/*LocalDateTime Date = LocalDateTime.now();
		Product product=new Product();
		product.setProductId(104);
		product.setProductName("p4");
		product.setPrice(400.00);
		product.setDate(Date);*/
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		
		//session.saveOrUpdate(product);
		
		//Query 1
		Query query=session.createQuery("from Product");
		List<Product> productList=query.list();
		for(Product pr:productList)
		{
			System.out.println(pr);
		}
		
		//Query2
		Query query2=session.createQuery("select e.productId,e.productName from Product as e where e.price>50");
		List<Object[]> productList2=query2.list();
		for(Object[] objArray:productList2)
		{
			for(Object obj:objArray)
			{
				System.out.print(obj+" ");
			}
			System.out.println();
		}
		
		//Query3
		Query query3=session.createQuery("select Max(e.price),Avg(e.price) from Product as e");
		List<Object[]> productList3=query3.list();
		for(Object[] objArray:productList3)
		{
			for(Object obj:objArray)
			{
				System.out.print(obj+" ");
			}
			System.out.println();
		}
		
		//Query 4
		Query query4=session.createQuery("select Count(e.productId) from Product as e");
		List<Long> productList4=query4.list();
		/*for(long productCount:productList4)
		{
			System.out.println(productCount);
		}*/
		System.out.println(productList4.get(0));
		
		//Query5
		Query query5=session.createQuery("select p.productId from Product p where p.price>:price1");
		//query5.setParameter("price1",new Scanner(System.in).nextDouble());
		query5.setParameter("price1",150.00);
		List<Integer> productList5=query5.list();
		for(int produ:productList5)
		{
			System.out.println(produ);
		}
		
		//Query6
		Query query6=session.createQuery("delete from Product p where p.price=:price1");
		//query6.setParameter("price1",new Scanner(System.in).nextDouble());
		query6.setParameter("price1", 50.00);
		System.out.println("Deleted");
		query6.executeUpdate();
		
		//Query7
		Query query7=session.createQuery("update Product p set p.price=400 where p.productId=:pid1");
		//query7.setParameter("pid1",new Scanner(System.in).nextInt());
		query7.setParameter("pid1", 104);
		System.out.println("Updated");
		query7.executeUpdate();
		
		//Method to use SQL queries
	/*	SQLQuery sqlQuery =session.createSQLQuery("select * from producttab");
		sqlQuery.addEntity(Product.class);
		List<Product> proList=sqlQuery.list();
		for(Product pr:proList)
		{
			System.out.println(pr);
		}
	//SQL Insertion Query
		SQLQuery sqlQuery2 =session.createSQLQuery("insert into producttab values(103,50,'p3',?)");
		sqlQuery2.setDate(0,date);
		query2.setParameter("pid1", 104);
		//sqlQuery2.addEntity(Product.class);
		System.out.println("Inserted");
		sqlQuery2.executeUpdate();
		*/
		//session.saveOrUpdate(product);
		
		//Using Criteria for minimizing queries
		Criteria criteria=session.createCriteria(Product.class);
		
		// PROJECTION LIST
		ProjectionList projectionList=Projections.projectionList();
		projectionList.add(Projections.property("productId")).add(Projections.property("price"));
		criteria.setProjection(projectionList);
		List<Object[]> proList=criteria.list();
		for(Object[] objArray:proList)
		{
			for(Object obj:objArray)
			{
				System.out.print(obj+" ");
			}
			System.out.println();
		}
/*		
  		//    RESTRICTIONS
		
		//SimpleExpression condition1=Restrictions.gt("price", 100.00);
		Criterion condition2=Restrictions.between("price", 150.00, 300.00);
		SimpleExpression condition1=Restrictions.gt("productId", 101);
		//criteria.add(condition1);
		LogicalExpression condition3=Restrictions.and(condition1, condition2);
		//LogicalExpression condition3=Restrictions.or(condition1, condition2);
		criteria.add(condition3);
			
		criteria.addOrder(Order.desc("price"));
		List<Product> productList6=criteria.list();
		for(Product pr:productList6)
		{
			System.out.println(pr);
		}
*/
		
		
		
		
		
		transaction.commit();
		session.close();
			
	}
	
}
