package com.virtusa.pmgmt.client;


import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.pmgmt.model.Product;

public class PersistenceMain
{
	public static void main(String[] args)
	{
		LocalDateTime Date = LocalDateTime.now();
		Product product=new Product();
		product.setProductId(104);
		product.setProductName("p4");
		product.setPrice(400.00);
		product.setDate(Date);
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.saveOrUpdate(product);
		
		
		
		transaction.commit();
		
		session.close();
		
		
		
	}
		
	
}
