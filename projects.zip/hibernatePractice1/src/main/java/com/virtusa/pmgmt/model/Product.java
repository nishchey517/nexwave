package com.virtusa.pmgmt.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.internal.NotNull;


@Entity
@Table(name="producttab")
public class Product 
{
	@Id
	@Column(name="product_id",length=10)
	private int productId;
	@Column(nullable=false)
	private String productName;
	@Column(nullable=false)
	private double price;
	@Column(nullable=false)
	private LocalDateTime date;
	
	
	public Product(int productId, String productName, double price, LocalDateTime date) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.date = date;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", date="
				+ date + "]";
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
