package com.hibernate.practice.app;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.practice.model.Employee;
import com.hibernate.practice.model.Employee2;

public class EmployeeMain 
{
	public static void main(String[] args)
	{
		Employee employee=new Employee();
		employee.setId(4);
		employee.setFirstName("Nishchey");
		employee.setLastName("Garg");
		employee.setAddress("Tuchi si jagah hyderabad ki");
		employee.setPincode(500075);
		
		Employee2 employee2=new Employee2();
		employee2.setId(5);
		employee2.setFirstName("Shubham");
		employee2.setLastName("Bansal");
		
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.saveOrUpdate(employee);
		session.saveOrUpdate(employee2);
		
		transaction.commit();
		session.close();
		
		
	}	
}
