package com.hibernate.practice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
@SecondaryTable(name = "employee_address")
public class Employee 
{	 
	    @Id
	   // @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(updatable = false, nullable = false)
	    private int id;	 
	    private String firstName;	 
	    private String lastName;	 
	    @Column(table = "employee_address")
	    private String address;	 
	    @Column(table = "employee_address")
	    private int pincode;
		public int getId() {
			return id;
		}
		public void setId(int i) {
			this.id = i;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getPincode() {
			return pincode;
		}
		public void setPincode(int pincode) {
			this.pincode = pincode;
		}
		@Override
		public String toString() {
			return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", address=" + address
					+ ", pincode=" + pincode + "]";
		}
		public Employee(int id, String firstName, String lastName, String address, int pincode) {
			super();
			this.id = id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.address = address;
			this.pincode = pincode;
		}
		public Employee() {
			super();
			// TODO Auto-generated constructor stub
		}
}
