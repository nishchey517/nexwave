package com.hibernate.practice.model;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employeedetails")
public class Edetail 
{
	@Id
	private int id;	 
    private String firstName;	 
    private String lastName;
    @Embedded
    private Eaddress address;
	public Edetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Edetail(int id, String firstName, String lastName, Eaddress address) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Eaddress getAddress() {
		return address;
	}
	public void setAddress(Eaddress address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Edetail [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", address=" + address
				+ "]";
	}
    
    
    
	
}
