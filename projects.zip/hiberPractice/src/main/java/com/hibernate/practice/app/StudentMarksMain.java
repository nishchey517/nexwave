package com.hibernate.practice.app;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.practice.model.MarksDetails;
import com.hibernate.practice.model.Student;

public class StudentMarksMain 
{
	public static void main(String[] args)
	{
		Student student=new Student("Shubham", "bansal", "shubham@gmail.com", "8427246463");
		Student student2=new Student("Nishchey", "Garg", "nishcheygarg517@gmail.com", "9478281090");
		MarksDetails marks1=new MarksDetails("Java", "100", "85", "Pass");
		//marks1.setStudent(student);
		MarksDetails marks2=new MarksDetails("Python", "100", "70", "Pass");
		//marks2.setStudent(student);
		MarksDetails marks3=new MarksDetails("DS", "100", "90", "Pass");
		//marks3.setStudent(student);
		
		ArrayList<MarksDetails> list=new ArrayList<MarksDetails>();
		list.add(marks1);
		list.add(marks2);
		list.add(marks3);
		student.setMarksDetails(list);
		student2.setMarksDetails(list);
		
	/*	marks1.setStudent(student);
		marks2.setStudent(student);
		marks1.setStudent(student2);
		marks3.setStudent(student2);
	*/	
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.save(student);
		session.save(student2);
	/*	session.saveOrUpdate(marks1);
		session.saveOrUpdate(marks2);
		session.saveOrUpdate(marks3);
	*/	
		
		transaction.commit();
		session.close();
		
		
	}	
}
