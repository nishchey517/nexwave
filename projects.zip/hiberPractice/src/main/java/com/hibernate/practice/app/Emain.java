package com.hibernate.practice.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.practice.model.Eaddress;
import com.hibernate.practice.model.Edetail;

public class Emain 
{
	public static void main(String[] args)
	{
		Eaddress address=new Eaddress("Patiala", "Punjab", "India", 147101);
		Edetail detail=new Edetail(1, "Nishchey", "Garg", address);
		Configuration configuration=new Configuration();
		configuration.configure("hibernate.cfg.xml");
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		session.saveOrUpdate(detail);
		//session.saveOrUpdate(employee2);
		
		transaction.commit();
		session.close();
		
		
	}	
	
	
}
