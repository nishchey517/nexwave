package com.hibernate.practice.app;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.practice.model.Author;
import com.hibernate.practice.model.Book;

public class OneToOne {
	public static void main(String[] args) {
		LocalDate Date = LocalDate.now();
		Author author = new Author(3, "Nishchey", "nishcheygarg517@gmail.com");
		Book book = new Book(4, "behla panti", "ways of enjoying life", Date);
		book.setAuthor(author);
		author.setBook(book);

		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();
		
	/*	SQLQuery sqlQuery =session.createSQLQuery("select a.author_id,a.email,a.name,b.description,b.author_id,b.book_id from author a join book b on a.author_id=b.author_id where b.title='behla panti' ");
		sqlQuery.addEntity(Author.class);
		sqlQuery.addEntity(Book.class);
		List<Object[]> proList=sqlQuery.list();
		for(Object[] objArray:proList)
		{
			for(Object obj:objArray)
			{
				System.out.print(obj+" ");
			}
			System.out.println();
		}
	*/	

//		session.save(author);
//		session.save(book);


		transaction.commit();
		session.close();

	}

}
