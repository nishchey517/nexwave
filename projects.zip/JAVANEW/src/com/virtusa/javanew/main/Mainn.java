package com.virtusa.javanew.main;

import java.util.HashSet;
import java.util.Iterator;

import com.virtusa.javanew.dayone.Customer;
import com.virtusa.javanew.dayone.Project;

public class Mainn {
	public static void main(String[] arg){
		boolean flag;
		Customer customer=new Customer(2361371,"ayan",8928799369l,"ayan@gmail.com");
		Customer customer1=new Customer(2361373,"ayan",8928799369l,"ayan@gmail.com");
		flag=customer.equals(customer1);
		System.out.println(flag);
		System.out.println(customer);
		//System.out.println(customer.hashCode());
		HashSet<Customer> hs=new HashSet<Customer>();
		hs.add(customer);
		hs.add(customer1);
		HashSet<Project> ps=new HashSet<Project>();
		Project p1=new Project(1212313,"Computer",89213.76f);
		Project p2=new Project(1212313,"laptop",532321.23f);
		Project p3=new Project(1212315,"machine",82321.23f);
		Project p4=new Project(1212316,"XUV",349243.23f);
		Project p5=new Project(1212317,"CPU",2323.23f);
		ps.add(p1);
		ps.add(p2);
		ps.add(p3);
		ps.add(p4);
		ps.add(p5);
		Iterator i=ps.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
		
		
	}
	
}
