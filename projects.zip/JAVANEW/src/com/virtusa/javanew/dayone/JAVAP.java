package com.virtusa.practice.model;

public class JAVAP {

}
