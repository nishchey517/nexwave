import java.util.*; 
class duplicates{  
 public static void main(String args[]){  
  Scanner scan = new Scanner(System.in);
       System.out.print("Enter Size of array:");
       int n=scan.nextInt();
       int a[]=new int[n],count=0;
       for(int i=0;i<n;i++)
	{	
       		System.out.print("Enter element of array:");
		a[i]=scan.nextInt();
	}
       for(int i=0;i<(n-1);i++)
	{
		for(int j=i+1;j<(n-i-1);j++)
		{
			if(a[i]==a[j])
			{
				for(int k=j;k<(a.length)-1;k++)
				{
					a[k]=a[k+1];	
				}
				count++;
				a[(a.length)-1]='\0';
			}
		}
	}
       for(int i=0;i<(a.length-count);i++)
	{
		       System.out.println("Array element="+a[i]);
	}
     
}  
}  