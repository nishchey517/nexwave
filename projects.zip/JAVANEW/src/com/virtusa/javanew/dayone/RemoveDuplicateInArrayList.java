package com.virtusa.javanew.dayone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

//Write a program to remove duplicate elements in the array list.

public class RemoveDuplicateInArrayList {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<Integer> list=new ArrayList<>();
		ArrayList<Integer> newList=new ArrayList<>();
		int n;
		System.out.println("Enter the elements:");
		while((n=s.nextInt())!=0){
			list.add(n);
		}
		//Collections.sort(list);
		for(Integer item:list){
			if(!newList.contains(item)){
				newList.add(item);
			}
		}
		for (int i = 0; i < list.size(); i++) {
			System.out.print(list.get(i)+ "  ");
		}
		System.out.println();
		for (int i = 0; i < newList.size(); i++) {
			System.out.print(newList.get(i)+"  ");
		}
		
		System.out.println();
	}
}
