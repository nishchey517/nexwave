import java.util.*;
import java.io.*;

class kaprekar  
{ 
    // Returns true if n is a Kaprekar number, else false 
    static boolean iskaprekar(int n) 
    { 
        if (n == 1) 
           return true; 
       
        // Count number of digits in square 
        int sq_n = n * n; 
	System.out.println("Square="+sq_n); 
        int count_digits = 0; 
        while (sq_n != 0) 
        { 
            count_digits++; 
            sq_n /= 10; 
        } 
	System.out.println("digits="+count_digits);
       
        sq_n = n*n; // Recompute square as it was changed 
       
        // Split the square at different poitns and see if sum 
        // of any pair of splitted numbers is equal to n. 
        for (int r_digits=1; r_digits<count_digits; r_digits++) 
        { 
             int eq_parts = (int) Math.pow(10, r_digits); 
       	System.out.println("eqparts="+eq_parts);
         
             if (eq_parts == n) 
                continue; 
       	System.out.println("eqparts,n="+eq_parts+n);
             // Find sum of current parts and compare with n 
             int sum = sq_n/eq_parts + sq_n % eq_parts;
	System.out.println("sq_n/eq_parts="+sq_n/eq_parts+"sq_n % eq_parts"+sq_n % eq_parts); 
             if (sum == n) 
               return true; 
        } 
       
        // compare with original number 
        return false; 
    } 
      
    // Driver method 
    public static void main (String[] args) 
    { 
        System.out.println("Printing first few Kaprekar Numbers" + 
                             " using iskaprekar()"); 
          
        for (int i=45; i<46; i++) 
            if (iskaprekar(i)) 
                 System.out.print(i + " "); 
    } 
} 

