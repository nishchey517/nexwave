package com.virtusa.javanew.dayone;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Country {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter total no of countries:");
		int n=s.nextInt();
		int c=0;
		Set<String> countries = new HashSet<String>();
		while(c!=n){
			countries.add(s.next());
			c++;
		}
		Iterator i=countries.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
		}
	}
}
