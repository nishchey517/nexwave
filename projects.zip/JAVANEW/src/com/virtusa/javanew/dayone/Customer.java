package com.virtusa.javanew.dayone;

//Create a class customer with fields customer id(long), customer name, mobile number, email address. When you print a 
//customer object it should display all the object fields.   
//================================================
//Lab: Override the equals and hash code methods in the customer class.
public class Customer {
	private long customerid;
	private String customername;
	private long phNo;
	private String email;

	@Override
	public String toString() {
		return "Customer is having id:" + customerid + ", customername=" + customername + ", phNo=" + phNo + ", email="
				+ email;
	}

	public boolean equals(Object o) {
		Customer c2 = (Customer) o;
		if (this.customerid == c2.getCustomerid())
			return true;
		else
			return false;
	}

	public int hashCode() {
		int id=(int) (customerid%10);
		return id;
	}

	public long getCustomerid() {
		return customerid;
	}

	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public long getPhNo() {
		return phNo;
	}

	public void setPhNo(long phNo) {
		this.phNo = phNo;
	}

	public String getEmail() {
		return email;
	}

	public Customer(long customerid, String customername, long phNo, String email) {
		super();
		this.customerid = customerid;
		this.customername = customername;
		this.phNo = phNo;
		this.email = email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
