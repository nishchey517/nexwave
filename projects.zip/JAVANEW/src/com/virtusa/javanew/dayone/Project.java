package com.virtusa.javanew.dayone;
/*  Create a class product with fields product id, product name and price. Create 5 objects of the class and add them to hashset.   
Iterate the hashset using a iterator and display all the products name and price only. Create the hashset in such a way that it 
should not accept any duplicate products when added. 
*/
public class Project {
	private long productid;
	private String productName;
	private float price;
	public Project(long productid,String productName,float price) {
		super();
		this.productid=productid;
		this.productName = productName;
		this.price = price;
	}
	public boolean equals(Object o){
		Project p=(Project)o;
		if(this.productid==p.getProductid()){
			return true;
		}
		else 
			return false;
		
	}
	public int hashCode(){
		int id=(int)this.productid;
		return id;
	}
	@Override
	public String toString() {
		return "Product with productid is:" + productid + " having price:" + price ;
	}
	public long getProductid() {
		return productid;
	}
	public void setProductid(long productid) {
		this.productid = productid;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	

}
