package com.virtusa.javanew.dayone;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
import java.io.*;

public class SortingStudents {

	public static void main(String[] args) throws Exception {
		
		BufferedReader d = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the no of students: \n");
		int n=Integer.parseInt(d.readLine());
		int t=n;
		int flag=0;
		TreeSet<String> students=new TreeSet<String>();
		
		Scanner s=new Scanner(System.in);
		while(n!=0){
			students.add(s.nextLine());
			n--;			
		}
		Iterator<String> i=students.iterator();
		while(i.hasNext()){
			String str=i.next();

			for(int j=0;j<str.length();j++){
				if((!Character.isLetter(str.charAt(j)) && str.charAt(j)!=' ')  ){
					flag=1;
				}
			}
			if(flag==1){
				i.remove();
			}
			flag=0;

		}
		Iterator<String> ii=students.iterator();
		while(ii.hasNext()){
			System.out.println(ii.next());
		}

	}


}
