package com.virtusa.practice.model;

import java.util.Scanner;

public class Practicepp {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter input");
	String str=s.next();
	//for(int i=0;i<)
	
	System.out.println(Character.isLetter('a'));
}
}
