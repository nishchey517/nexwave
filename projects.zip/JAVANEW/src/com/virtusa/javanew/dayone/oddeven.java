import java.util.*; 
class oddeven{  
 public static void main(String args[]){  
  Scanner scan = new Scanner(System.in);
        System.out.print("Enter 0 to exit/see Results ,Enter Input:");
       
        int n,odd=0,even=0;
        while((n=scan.nextInt())!=0)
	{
		//n=scan.nextInt;
		if(n%2==0)
		even=even+n;
		else
		odd=odd+n;
	System.out.print("Enter Input:");
	}	
       System.out.println("Odd sum="+odd);
       System.out.println("Even sum="+even);
}  
}  