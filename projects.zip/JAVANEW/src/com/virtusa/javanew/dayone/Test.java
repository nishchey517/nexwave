package com.virtusa.javanew.dayone;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char ch = 's';
		
		System.out.println((int)ch);
		
		

	}

}
