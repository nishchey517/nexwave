package com.virtusa.javanew.dayone;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.io.*;

public class list2ndMax 
{
	public static void main(String[] args) throws Exception {

		LinkedList<Integer> list=new LinkedList<>();

		BufferedReader d = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the elements. Enter $ to stop");

		while(true) {

			String input = d.readLine();

			if(input.equals("$")) {
                break;  
			}
			else {
				int num = Integer.parseInt(input);
				list.add(num);
			}

		}
		
		System.out.println(list);


		int ma=0,ma2=0;
		for(int j=0;j<list.size();j++)
		{
			if(list.get(j)>ma)
			{				
				ma2=ma;
				ma=list.get(j);				
			}
			else if(list.get(j)>ma2 && list.get(j)!=ma)
			{
				ma2=list.get(j);
			}
		}
		for(int j=0;j<list.size();j++)
		{
			System.out.print(list.get(j)+" ");
		}
		System.out.println("2nd maximum="+ma2);
	}
}
