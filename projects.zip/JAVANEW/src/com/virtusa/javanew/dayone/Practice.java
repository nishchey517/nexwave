package com.virtusa.practice.model;

public class Practice {
public static void main(String[] args) {
	int a=5,b=5;
	System.out.println(2.3f+"hello");
	System.out.println(2.33+3);
	System.out.println('c'+"hello");
	System.out.println(54343434+23213.344);/*//"fcdsn");*/
	System.out.println(2+'c'+3.3f+3434L+"hello"+'c'+true);
	System.out.println('c'+'a');
	JAVAP p=new JAVAP();
	JAVAP pp=new JAVAP();
	JAVAP ppp=p;
	System.out.println(p==pp);
	System.out.println(p.equals(pp));
	System.out.println(p==ppp);
	System.out.println(p.equals(ppp));
	System.out.println(a==b);
	
	
}
}
