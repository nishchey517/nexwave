package somePackage;

public class Vehicle {
	
	String name;
	
	public Vehicle( ) { }
	
	public Vehicle(String name) {
		this.name = name;
	}
	
	public String toString( ) {
		
		return name;
	}	
}


