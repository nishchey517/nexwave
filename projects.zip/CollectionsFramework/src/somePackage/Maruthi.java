package somePackage;

public class Maruthi extends Car  {
	
	String name;
	
	public Maruthi( ) { }
	
	public Maruthi(String name) {		
		this.name = name;
	}
	
    public String toString( ) {
		
		return name;
	}
	
}

