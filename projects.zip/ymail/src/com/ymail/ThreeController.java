package com.ymail;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ThreeController
 */
public class ThreeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ThreeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	
		String username=request.getParameter("username");
		String gender=request.getParameter("gender");
		String Email=request.getParameter("email");
		String password=request.getParameter("password");
		
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		
		out.println("username="+username);
		out.println("gender="+gender);
		out.println("email="+Email);
		out.println("password="+password);
		out.println("phone="+phone);
		out.println("address="+address);
	}

}
